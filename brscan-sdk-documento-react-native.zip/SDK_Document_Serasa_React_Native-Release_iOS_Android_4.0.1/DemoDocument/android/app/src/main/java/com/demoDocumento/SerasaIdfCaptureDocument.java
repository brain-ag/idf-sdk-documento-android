package com.demoDocumento;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

import com.facebook.react.bridge.ActivityEventListener;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.lang.reflect.Field;

import br.com.brscan.sdk.captura.activities.DocumentoActivity;
import br.com.brscan.sdk.captura.handles.FinalizaJornadaCallback;
import br.com.brscan.sdk.captura.models.ConfiguracaoTexto;
import br.com.brscan.sdk.captura.models.Documento;
import br.com.brscan.sdk.captura.models.Erro;

public class SerasaIdfCaptureDocument extends ReactContextBaseJavaModule implements ActivityEventListener {

    private static final String TAG = "CaptureDocument";
    private static final int REQUEST_CODE_DOCUMENT = 1003;

    private DocumentoConfiguracao configuracaoDocumento;

    private Callback successCallback;
    private Callback errorCallback;
    private Callback callbackListener;


    public SerasaIdfCaptureDocument(ReactApplicationContext context) {
        super(context);
        context.addActivityEventListener(this);
    }

    @Override
    public String getName() {
        return "SerasaIdfCaptureDocument";
    }


    @ReactMethod
    public void captureDocumentCallBackListener(Callback callbackListener) {
        this.callbackListener = callbackListener;
    }


    @ReactMethod
    public void captureDocument(String chave,
                                boolean cropDocumento,
                                Integer timeoutCapturaManual,
                                boolean wizard,
                                Boolean aceitaAB,
                                ReadableArray tiposDocumentosAceitos,
                                String ladoDocumentoAceito,
                                boolean validaDocumento,
                                boolean segurancaExtraSslPinning,
                                boolean segurancaExtraRootCheck,
                                boolean verificarLuminosidade,
                                boolean telaSelecaoDocumento,
                                boolean telaPreview,
                                String resolucao,
                                String tipoRetorno,
                                int scoreMinimo,
                                ReadableMap configuracaoTextoWritable,
                                boolean retornarErros,
                                boolean segurancaExtraEmulatorCheck,
                                int tokenTentativa,
                                boolean capturaManual,
                                String orientacaoCaptura,
                                int tentativasDeCaptura,
                                boolean telaConfirmacaoDeSaida,
                                boolean spoof,
                                int tentativasExibicaoBotao,
                                boolean playCaptureSound,
                                Callback successCallback,
                                Callback errorCallback
    ) {
        Log.d(TAG, "start: ");
        this.configuracaoDocumento = new DocumentoConfiguracao(
                chave,
                cropDocumento,
                timeoutCapturaManual,
                wizard,
                aceitaAB,
                tiposDocumentosAceitos,
                ladoDocumentoAceito,
                validaDocumento,
                segurancaExtraSslPinning,
                segurancaExtraRootCheck,
                verificarLuminosidade,
                telaSelecaoDocumento,
                telaPreview,
                resolucao,
                tipoRetorno,
                scoreMinimo,
                configuracaoTextoWritable,
                retornarErros,
                segurancaExtraEmulatorCheck,
                tokenTentativa,
                capturaManual,
                orientacaoCaptura,
                tentativasDeCaptura,
                telaConfirmacaoDeSaida,
                spoof,
                tentativasExibicaoBotao,
                playCaptureSound
        );
        this.successCallback = successCallback;
        this.errorCallback = errorCallback;
        iniciaCapturaDocumento();
    }

    private void iniciaCapturaDocumento() {
        Intent intent = new Intent(getCurrentActivity(), DocumentoActivity.class);
        intent.putExtra("chave", configuracaoDocumento.getChave());
        intent.putExtra("cropDocumento", configuracaoDocumento.isCropDocumento());
        if (configuracaoDocumento.getTimeoutCapturaManual() != null)
            intent.putExtra("timeoutCapturaManual", configuracaoDocumento.getTimeoutCapturaManual());

        intent.putExtra("wizard", configuracaoDocumento.isWizard());
        if (configuracaoDocumento.isAceitaAB() != null)
            intent.putExtra("aceitaAB", configuracaoDocumento.isAceitaAB());
        if (configuracaoDocumento.getTiposDocumentosAceitos() != null)
            intent.putExtra("tiposDocumentosAceitos", configuracaoDocumento.getTiposDocumentosAceitos());

        intent.putExtra("validaDocumento", configuracaoDocumento.getValidaDocumento());
        intent.putExtra("verificarLuminosidade", false);
        intent.putExtra("configuracaoTexto", this.configuracaoDocumento.getConfiguracaoTexto());
        intent.putExtra("segurancaExtraSslPinning", this.configuracaoDocumento.isSegurancaExtraSslPinning());
        intent.putExtra("segurancaExtraRootCheck", this.configuracaoDocumento.isSegurancaExtraRootCheck());
        intent.putExtra("wizard", this.configuracaoDocumento.isWizard());
        intent.putExtra("verificarLuminosidade", this.configuracaoDocumento.isVerificarLuminosidade());
        intent.putExtra("ladoDocumentoAceito", this.configuracaoDocumento.getLadoDocumentoAceito());
        intent.putExtra("telaSelecaoDocumento", this.configuracaoDocumento.isTelaSelecaoDocumento());
        intent.putExtra("telaPreview", this.configuracaoDocumento.isTelaPreview());
        intent.putExtra("resolucao", this.configuracaoDocumento.getResolucao());
        intent.putExtra("tipoRetorno", this.configuracaoDocumento.getTipoRetorno());
        intent.putExtra("retornarErros", this.configuracaoDocumento.isRetornarErros());
        intent.putExtra("scoreMinimo", this.configuracaoDocumento.getScoreMinimo());
        intent.putExtra("segurancaExtraEmulatorCheck", this.configuracaoDocumento.isSegurancaExtraEmulatorCheck());
        intent.putExtra("tokenTentativa", this.configuracaoDocumento.getTokenTentativa());
        intent.putExtra("capturaManual", this.configuracaoDocumento.isCapturaManual());
        intent.putExtra("orientacaoCaptura", this.configuracaoDocumento.getOrientacaoCaptura());
        intent.putExtra("tentativasDeCaptura", this.configuracaoDocumento.getTentativasDeCaptura());
        intent.putExtra("telaConfirmacaoDeSaida", this.configuracaoDocumento.isTelaConfirmacaoDeSaida());
        intent.putExtra("spoof", this.configuracaoDocumento.isSpoof());
        intent.putExtra("tentativasExibicaoBotao", this.configuracaoDocumento.getTentativasExibicaoBotao());
        intent.putExtra("playCaptureSound", this.configuracaoDocumento.isPlayCaptureSound());

        DocumentoActivity.documentCallbackListener = result -> {

            try {
                int code = result.getInt("code");
                String id = result.getString("id");
                String description = result.getString("description");
                int time = result.getInt("time");
                String type = result.getString("type");
                String docType = result.has("docType") ? result.getString("docType") : "";
                String image = result.has("image") ? result.getString("image") : "";


                WritableMap errorMap = Arguments.createMap();

                errorMap.putInt("code", code);
                errorMap.putString("id", id);
                errorMap.putString("description", description);
                errorMap.putInt("time", time);
                errorMap.putString("type", type);
                errorMap.putString("docType", docType);
                errorMap.putString("image", image);

                if (callbackListener != null) {
                    callbackListener.invoke(errorMap);
                }

            } catch (Exception e) {
                Log.d(TAG, "onCallback: " + e.getMessage());
            }
        };

        if (getCurrentActivity() != null)
            getCurrentActivity().startActivityForResult(intent, REQUEST_CODE_DOCUMENT);
    }

    @Override
    public void onActivityResult(Activity activity, int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CODE_DOCUMENT) {
                Documento[] documents = (Documento[]) data.getSerializableExtra("documentos");
                if (documents != null) {

                    WritableArray documentsWritable = Arguments.createArray();

                    for (Documento document : documents) {
                        WritableMap documentoMap = Arguments.createMap();

                        documentoMap.putString("id", document.getId());
                        documentoMap.putString("imagem", document.getImagem());
                        documentoMap.putString("tipo", document.getTipo());
                        documentoMap.putString("score", document.getScore());

                        WritableMap boundingBoxMap = Arguments.createMap();

                        boundingBoxMap.putInt("x", document.getBoundingBox().getX());
                        boundingBoxMap.putInt("y", document.getBoundingBox().getY());
                        boundingBoxMap.putInt("width", document.getBoundingBox().getWidth());
                        boundingBoxMap.putInt("height", document.getBoundingBox().getHeight());

                        documentoMap.putMap("boundingBox", boundingBoxMap);

                        documentsWritable.pushMap(documentoMap);
                    }
                    if (successCallback != null) successCallback.invoke(documentsWritable);

                } else {
                    Erro erro = (Erro) data.getSerializableExtra("erro");
                    if (erro != null) {
                        WritableMap erroMap = Arguments.createMap();

                        erroMap.putInt("codigo", erro.getCodigo());
                        erroMap.putString("descricao", erro.getDescricao());
                        erroMap.putString("id", erro.getId());

                        if (errorCallback != null) errorCallback.invoke(erroMap);
                    }
                }
            }
        }
    }


    @ReactMethod
    private void finishJourney(String chave, boolean segurancaExtraSslPinning, Callback sucessoCallback, Callback erroCallback) {
        DocumentoActivity.finalizaJornadaSDK(
                getCurrentActivity(),
                chave,
                segurancaExtraSslPinning,
                new FinalizaJornadaCallback() {
                    @Override
                    public void sucessoFinalizar(JSONObject resultadoSucesso) {
                        try {
                            String id = resultadoSucesso.getString("id");

                            WritableMap result = Arguments.createMap();
                            result.putString("id", id);

                            if (sucessoCallback != null) {
                                sucessoCallback.invoke(result);
                            }

                        } catch (JSONException e) {
                            Log.d(TAG, "Error " + e.getMessage());
                        }
                    }

                    @Override
                    public void erroFinalizar(JSONObject resultadoErro) {
                        try {
                            String code = resultadoErro.getString("codigo");
                            String description = resultadoErro.getString("descricao");


                            WritableMap result = Arguments.createMap();
                            result.putString("codigo", code);
                            result.putString("descricao", description);

                            if (erroCallback != null) {
                                erroCallback.invoke(result);
                            }

                        } catch (JSONException e) {
                            Log.d(TAG, "Error " + e.getMessage());
                        }
                    }
                });
    }

    @Override
    public void onNewIntent(Intent intent) {
    }

    private static class DocumentoConfiguracao implements Serializable {
        private final String chave;
        private final boolean cropDocumento;
        private final Integer timeoutCapturaManual;
        private final boolean wizard;
        private final Boolean aceitaAB;
        private final String[] tiposDocumentosAceitos;
        private final Boolean validaDocumento;
        private final String ladoDocumentoAceito;
        private final boolean segurancaExtraRootCheck;
        private final boolean segurancaExtraSslPinning;
        private final boolean verificarLuminosidade;
        private final boolean telaSelecaoDocumento;
        private final boolean telaPreview;
        private final String resolucao;
        private final String tipoRetorno;
        private ConfiguracaoTexto configuracaoTexto;
        private final boolean retornarErros;
        private final int scoreMinimo;
        private final boolean segurancaExtraEmulatorCheck;
        private final int tokenTentativa;
        private final boolean capturaManual;
        private final String orientacaoCaptura;
        private final int tentativasDeCaptura;
        private final boolean telaConfirmacaoDeSaida;
        private final boolean spoof;
        private final int tentativasExibicaoBotao;
        private final boolean playCaptureSound;

        public DocumentoConfiguracao(
                String chave,
                boolean cropDocumento,
                Integer timeoutCapturaManual,
                boolean wizard,
                Boolean aceitaAB,
                ReadableArray tiposDocumentosAceitos,
                String ladoDocumentoAceito,
                Boolean validaDocumento,
                boolean segurancaExtraSslPinning,
                boolean segurancaExtraRootCheck,
                boolean verificarLuminosidade,
                boolean telaSelecaoDocumento,
                boolean telaPreview,
                String resolucao,
                String tipoRetorno,
                int scoreMinimo,
                ReadableMap configuracaoTextoWritable,
                boolean retornarErros,
                boolean segurancaExtraEmulatorCheck,
                int tokenTentativa,
                boolean capturaManual,
                String orientacaoCaptura,
                int tentativasDeCaptura,
                boolean telaConfirmacaoDeSaida,
                boolean spoof,
                int tentativasExibicaoBotao,
                boolean playCaptureSound
        ) {
            this.chave = chave;
            this.cropDocumento = cropDocumento;
            this.timeoutCapturaManual = timeoutCapturaManual;
            this.wizard = wizard;
            this.aceitaAB = aceitaAB;
            this.tiposDocumentosAceitos = readableArrayToStringList(tiposDocumentosAceitos);
            this.ladoDocumentoAceito = ladoDocumentoAceito;
            this.validaDocumento = validaDocumento;
            this.segurancaExtraRootCheck = segurancaExtraRootCheck;
            this.segurancaExtraSslPinning = segurancaExtraSslPinning;
            this.verificarLuminosidade = verificarLuminosidade;
            this.telaSelecaoDocumento = telaSelecaoDocumento;
            this.telaPreview = telaPreview;
            this.resolucao = resolucao;
            this.tipoRetorno = tipoRetorno;
            this.retornarErros = retornarErros;
            this.scoreMinimo = scoreMinimo;
            this.segurancaExtraEmulatorCheck = segurancaExtraEmulatorCheck;
            this.tokenTentativa = tokenTentativa;
            this.capturaManual = capturaManual;
            this.orientacaoCaptura = orientacaoCaptura;
            this.tentativasDeCaptura = tentativasDeCaptura;
            this.telaConfirmacaoDeSaida = telaConfirmacaoDeSaida;
            this.spoof = spoof;
            this.tentativasExibicaoBotao = tentativasExibicaoBotao;
            this.playCaptureSound = playCaptureSound;
            readableMapSelfieConfiguracaoTexto(configuracaoTextoWritable);
        }

        public String getChave() {
            return chave;
        }

        public boolean isCropDocumento() {
            return cropDocumento;
        }

        public Integer getTimeoutCapturaManual() {
            return timeoutCapturaManual;
        }

        public boolean isWizard() {
            return wizard;
        }

        public Boolean isAceitaAB() {
            return aceitaAB;
        }

        public String[] getTiposDocumentosAceitos() {
            return tiposDocumentosAceitos;
        }

        public Boolean getValidaDocumento() {
            return validaDocumento;
        }

        public String getLadoDocumentoAceito() {
            return ladoDocumentoAceito;
        }

        public ConfiguracaoTexto getConfiguracaoTexto() {
            return configuracaoTexto;
        }

        public boolean isSegurancaExtraRootCheck() {
            return segurancaExtraRootCheck;
        }

        public boolean isSegurancaExtraSslPinning() {
            return segurancaExtraSslPinning;
        }

        public boolean isSegurancaExtraEmulatorCheck() {
            return segurancaExtraEmulatorCheck;
        }

        public boolean isVerificarLuminosidade() {
            return verificarLuminosidade;
        }

        public boolean isTelaSelecaoDocumento() {
            return telaSelecaoDocumento;
        }

        public boolean isTelaPreview() {
            return telaPreview;
        }

        public String getResolucao() {
            return resolucao;
        }

        public String getTipoRetorno() {
            return tipoRetorno;
        }

        public boolean isRetornarErros() {
            return retornarErros;
        }

        public int getScoreMinimo() {
            return scoreMinimo;
        }

        private static String[] readableArrayToStringList(final ReadableArray array) {
            if (array == null) return null;
            String[] stringList = new String[array.size()];

            for (int i = 0, l = array.size(); i < l; i++) {
                stringList[i] = array.getString(i);
            }

            return stringList;
        }

        public int getTokenTentativa() {
            return tokenTentativa;
        }

        public boolean isCapturaManual() {
            return capturaManual;
        }

        public String getOrientacaoCaptura() {
            return orientacaoCaptura;
        }

        public int getTentativasDeCaptura() {
            return tentativasDeCaptura;
        }

        public boolean isTelaConfirmacaoDeSaida() {
            return telaConfirmacaoDeSaida;
        }

        public boolean isSpoof() {
            return spoof;
        }

        public int getTentativasExibicaoBotao() {
            return tentativasExibicaoBotao;
        }

        public boolean isPlayCaptureSound() {
            return playCaptureSound;
        }

        private void readableMapSelfieConfiguracaoTexto(ReadableMap configuracaoWritable) {
            configuracaoTexto = new ConfiguracaoTexto();
            if (configuracaoWritable == null) return;

            Field[] fs = configuracaoTexto.getClass().getFields();
            for (Field fild : fs) {
                try {
                    String value = configuracaoWritable.getString(fild.getName());
                    fild.set(configuracaoTexto, value);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
