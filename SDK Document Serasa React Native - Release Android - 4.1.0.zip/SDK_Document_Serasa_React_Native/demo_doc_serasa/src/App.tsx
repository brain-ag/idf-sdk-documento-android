import * as React from 'react';

import { StyleSheet, View, TouchableOpacity, Text, ScrollView } from 'react-native';
import { ErrorDocument, Document, DocumentConfig, startDocument, ListenerResult, documentCallbackListener } from './native_module_document';

export default function App() {


    const [resultSuccessDocument, setResultSuccessDocument] = React.useState<Document[] | null>(null);
    const [resultErrorDocument, setResultErrorDocument] = React.useState<ErrorDocument | null>(null);

    // Document

    const documentConfig: DocumentConfig = {
        chave: '',// INSERT KEY HERE
        cropDocumento: true,
        validaDocumento: true,
        timeoutCapturaManual: 2,
        segurancaExtraRootCheck: true,// TO CHECK IF DEVICE IS RUNNING IN ROOT MODE (BY DEFAULT IS FALSE)
        segurancaExtraSslPinning: true,// TO VALIDATE REQUESTS WITH SSL PINNING (BY DEFAULT IS FALSE)
        segurancaExtraEmulatorCheck: true,// TO CHECK IF DEVICE IS A EMULATOR (BY DEFAULT IS FALSE)
        wizard: true,
        verificarLuminosidade: false,
        tiposDocumentosAceitos: ["cnh", "rg", "dni", "rnm", "rne", "cnhcel2022", "cnhdig2022", "outros", "outrosdig"],
        aceitaAB: false,
        ladoDocumentoAceito: '',
        telaSelecaoDocumento: true,
        telaPreview: true,
        resolucao: 'low',
        tipoRetorno: 'base64',
        scoreMinimo: 60,
        retornarErros: false,
        capturaManual: false,
        telaConfirmacaoDeSaida: true,
        spoof: true,
        tentativasExibicaoBotao: 3,
        orientacaoCaptura: 'portrait',
        tentativasDeCaptura: 0,
        tokenTentativa: 0,
        playCaptureSound: false,
        spoofValidationExceptions: [""],
        customizacaoTexto: {
            brscan_documento_error_upload_size_subtitle: "Arquivo selecionado maior que o tamanho permitido de 1MB.",
            brscan_documento_uploading_digital_file_subtitle: "Estamos carregando seu documento digital",
            brscan_documento_uploading_digital_file_preparation_subtitle: "Estamos preparando para receber seu arquivo",
            brscan_documento_loading_title: "Aguarde um instante...",
           /*
           
            ...

            */

        }

    }

    const handleDocumentSuccess = (documentos: Document[]) => {
        const json = JSON.stringify(documentos, null, 2)
        console.log(json)
        setResultErrorDocument(null);
        setResultSuccessDocument(documentos);
    }

    const handleDocumentErro = (error: ErrorDocument) => {
        const json = JSON.stringify(error, null, 2)
        console.log(json)
        setResultErrorDocument(error);
        setResultSuccessDocument(null);
    }

    const callbackListener = (result: ListenerResult) => {
        const json = JSON.stringify(result, null, 2)
        console.log(json)
    }

    const handleDocumentStart = () => {
        documentCallbackListener(callbackListener);
        startDocument(documentConfig, handleDocumentSuccess, handleDocumentErro)
    }

    return (
        <View style={styles.container}>
            <View style={{ height: 300 }}>
                <ScrollView>
                    {
                        resultSuccessDocument &&
                        resultSuccessDocument.map(document => (
                            <Text style={styles.resultText} key={document.id}>
                                id:  {document.id + "\n\n"}
                                imagem:  {document.imagem.substring(0, 200) + "...\n\n"}
                                score:  {document.score + "...\n\n"}
                                tipo:  {document.tipo + "...\n\n"}
                                boundingBoxMap:  {
                                    JSON.stringify(document.boundingBox, null, 2) + "...\n\n"}
                            </Text>
                        ))


                    }
                    {
                        resultErrorDocument && <Text style={styles.resultText}>
                            id:  {resultErrorDocument.id + "\n\n"}
                            codigo:  {resultErrorDocument.codigo + "\n\n"}
                            descricao:  {resultErrorDocument.descricao + "\n\n"}
                        </Text>

                    }

                </ScrollView>
            </View>

            <TouchableOpacity onPress={handleDocumentStart} style={styles.button}>
                <Text style={styles.buttonTitle}>Capture Document</Text>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-evenly',
        backgroundColor: "#f5f5f5"
    },
    box: {
        width: 60,
        height: 60,
        marginVertical: 20,
    },
    button: {
        width: "80%",
        height: 56,
        backgroundColor: "#002DD1",
        borderRadius: 56,
        alignItems: 'center',
        justifyContent: 'center'
    },
    buttonTitle: {
        color: "#f5f5f5",
        fontSize: 16
    },
    resultText: {
        color: "#333",
        fontSize: 16,
        padding: 16
    }
});
