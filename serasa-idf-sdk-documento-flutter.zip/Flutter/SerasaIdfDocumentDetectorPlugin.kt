package serasa.idf.document

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.annotation.NonNull
import br.com.brscan.sdk.captura.activities.DocumentoActivity
import br.com.brscan.sdk.captura.handles.DocumentCallbackListener
import br.com.brscan.sdk.captura.models.BoundingBox
import br.com.brscan.sdk.captura.models.ConfiguracaoTexto
import br.com.brscan.sdk.captura.models.Documento
import br.com.brscan.sdk.captura.models.Erro
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.FlutterPlugin.FlutterPluginBinding
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.PluginRegistry.ActivityResultListener
import java.lang.reflect.Field

class SerasaIdfDocumentDetectorPlugin : FlutterPlugin, MethodCallHandler, ActivityAware,
    ActivityResultListener {
    private lateinit var configuracaoTexto: ConfiguracaoTexto
    private lateinit var channel: MethodChannel
    private var activity: Activity? = null
    private var pendingResult: MethodChannel.Result? = null
    private var pendingCallbackResult: MethodChannel.Result? = null
    private var context: Context? = null
    private val listSDKDocumentMethod = listOf(
        DART_TO_SDK_EVENT_START_CAPTURE,
        DART_TO_SDK_EVENT_DOCUMENT_CALLBACK_LISTENER
    )

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        if (listSDKDocumentMethod.contains(call.method)) {
            if (call.method == DART_TO_SDK_EVENT_DOCUMENT_CALLBACK_LISTENER) {
                pendingCallbackResult = result;
            } else {
                pendingResult = result
                start(call)
            }


            return
        } else {
            result.notImplemented()
        }
    }

    private fun start(call: MethodCall) {
        when (call.method) {
            DART_TO_SDK_EVENT_START_CAPTURE -> {
                val listDocAllowed =
                    call.argument<ArrayList<String>>(SDK_PARAM_TIPOS_DOCUMENTOS_ACEITOS)
                val arrayDocAllowed: Array<String>? = listDocAllowed?.toTypedArray()
                val configuracaoTextoParamSdk = readableMapSelfieConfiguracaoTexto(
                    call.argument<Map<String, String>>(SDK_PARAM_CONFIGURACAO_TEXTO)
                )

                val intent = Intent(context, DocumentoActivity::class.java)
                intent.putExtra(SDK_PARAM_CHAVE, call.argument<String>(SDK_PARAM_CHAVE))
                intent.putExtra(SDK_PARAM_WIZARD, call.argument<Boolean>(SDK_PARAM_WIZARD))
                intent.putExtra(SDK_PARAM_ACEITA_AB, call.argument<Boolean>(SDK_PARAM_ACEITA_AB))
                intent.putExtra(
                    SDK_PARAM_SSL_PINNING,
                    call.argument<Boolean>(SDK_PARAM_SSL_PINNING)
                )
                intent.putExtra(
                    SDK_PARAM_LADO_DOCUMENTO_ACEITO,
                    call.argument<String>(SDK_PARAM_LADO_DOCUMENTO_ACEITO)
                )
                intent.putExtra(
                    SDK_PARAM_TELA_CONFIRMACAO_SAIDA,
                    call.argument<Boolean>(SDK_PARAM_TELA_CONFIRMACAO_SAIDA)
                )
                intent.putExtra(
                    SDK_PARAM_TELA_SELECAO_DOCUMENTO,
                    call.argument<Boolean>(SDK_PARAM_TELA_SELECAO_DOCUMENTO)
                )
                intent.putExtra(
                    SDK_PARAM_CAPTURA_MANUAL,
                    call.argument<Boolean>(SDK_PARAM_CAPTURA_MANUAL)
                )
                intent.putExtra(
                    SDK_PARAM_ORIENTACAO_CAPTURA,
                    call.argument<String>(SDK_PARAM_ORIENTACAO_CAPTURA)
                )
                intent.putExtra(SDK_PARAM_SCORE_MINIMO, call.argument<Int>(SDK_PARAM_SCORE_MINIMO))
                intent.putExtra(
                    SDK_PARAM_VERIFICAR_LUMINOSIDADE,
                    call.argument<Boolean>(SDK_PARAM_VERIFICAR_LUMINOSIDADE)
                )
                intent.putExtra(
                    SDK_PARAM_CROP_DOCUMENTO,
                    call.argument<Boolean>(SDK_PARAM_CROP_DOCUMENTO)
                )
                intent.putExtra(
                    SDK_PARAM_VALIDA_DOCUMENTO,
                    call.argument<Boolean>(SDK_PARAM_VALIDA_DOCUMENTO)
                )
                intent.putExtra(
                    SDK_PARAM_TIMEOUT_CAPTURA_MANUAL,
                    call.argument<Double>(SDK_PARAM_TIMEOUT_CAPTURA_MANUAL)
                )
                intent.putExtra(SDK_PARAM_TIPOS_DOCUMENTOS_ACEITOS, arrayDocAllowed)
                intent.putExtra(SDK_PARAM_CONFIGURACAO_TEXTO, configuracaoTextoParamSdk)
                intent.putExtra(
                    SDK_PARAM_RETORNAR_ERROS,
                    call.argument<Boolean>(SDK_PARAM_RETORNAR_ERROS)
                )
                intent.putExtra(
                    SDK_PARAM_SEGURANCA_EXTRA_ROOT_CHECK,
                    call.argument<Boolean>(SDK_PARAM_SEGURANCA_EXTRA_ROOT_CHECK)
                )
                intent.putExtra(
                    SDK_PARAM_SEGURANCA_EXTRA_EMULATOR_CHECK,
                    call.argument<Boolean>(SDK_PARAM_SEGURANCA_EXTRA_EMULATOR_CHECK)
                )
                intent.putExtra(
                    SDK_PARAM_RETURN_TYPE,
                    call.argument<String>(SDK_PARAM_RETURN_TYPE)
                )


                intent.putExtra(SDK_PARAM_RESOLUCAO, call.argument<String>(SDK_PARAM_RESOLUCAO))
                intent.putExtra(
                    SDK_PARAM_TENTATIVAS_CAPTURA,
                    call.argument<Int>(SDK_PARAM_TENTATIVAS_CAPTURA)
                )

                intent.putExtra(
                    SDK_PARAM_KEY_ENABLE_BUTTON_ATTEMPT,
                    call.argument<Int>(SDK_PARAM_KEY_ENABLE_BUTTON_ATTEMPT)
                )

                intent.putExtra(
                    SDK_PARAM_PLAY_CAPTURE_SOUND,
                    call.argument<Boolean>(SDK_PARAM_PLAY_CAPTURE_SOUND)
                )

                DocumentoActivity.documentCallbackListener = DocumentCallbackListener {
                    val response = HashMap<String, Any>()
                    response.put(SDK_RESPONSE_CALLBACK_RESULT_CODE, it.get(
                        SDK_RESPONSE_CALLBACK_RESULT_CODE))
                    response.put(SDK_RESPONSE_CALLBACK_RESULT_DESCRIPTION, it.get(
                        SDK_RESPONSE_CALLBACK_RESULT_DESCRIPTION))
                    response.put(SDK_RESPONSE_CALLBACK_RESULT_ID, it.get(
                        SDK_RESPONSE_CALLBACK_RESULT_ID))
                    response.put(SDK_RESPONSE_CALLBACK_RESULT_TIME, it.get(
                        SDK_RESPONSE_CALLBACK_RESULT_TIME))
                    response.put(SDK_RESPONSE_CALLBACK_RESULT_TYPE, it.get(
                        SDK_RESPONSE_CALLBACK_RESULT_TYPE))
                    if(it.has(
                        SDK_RESPONSE_CALLBACK_RESULT_DOC_TYPE)){
                        response.put(SDK_RESPONSE_CALLBACK_RESULT_DOC_TYPE, it.get(
                            SDK_RESPONSE_CALLBACK_RESULT_DOC_TYPE))
                    }else{
                        response.put(SDK_RESPONSE_CALLBACK_RESULT_DOC_TYPE, "")
                    }

                    if( it.has(SDK_RESPONSE_CALLBACK_RESULT_IMAGE)){
                        response.put(SDK_RESPONSE_CALLBACK_RESULT_IMAGE, it.get(
                            SDK_RESPONSE_CALLBACK_RESULT_IMAGE))
                    }else{
                        response.put(SDK_RESPONSE_CALLBACK_RESULT_IMAGE, "")
                    }


                    pendingCallbackResult?.success(response)
                }
                activity?.startActivityForResult(intent, CODE_START_CAPTURE)
            }
            else -> {
                pendingResult?.notImplemented()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode == CODE_START_CAPTURE) {
            if (resultCode == Activity.RESULT_OK) {
                val documents = data?.getSerializableExtra(SDK_RESPONSE_LIST_OF_DOCUMENTS)
                documents?.let {
                    val list = mutableListOf<Map<String, Any>>()
                    (documents as Array<Documento>).forEach { document ->
                        val parameter = HashMap<String, Any>()
                        val boundingBoxMap = transformBoundingBoxToMap(document.boundingBox)
                        parameter.put(SDK_PARAM_ID, document.id)
                        parameter.put(SDK_PARAM_TYPE, document.tipo)
                        parameter.put(SDK_PARAM_SCORE, document.score)
                        parameter.put(SDK_PARAM_IMAGE, document.getImagem())
                        parameter.put(SDK_PARAM_BOUNDING_BOX, boundingBoxMap)
                        list.add(parameter)
                    }
                    val response = HashMap<String, Any>();
                    response.put(SDK_RESPONSE_LIST_OF_DOCUMENTS, list)
                    pendingResult?.success(response)
                }

                val error = data?.getSerializableExtra(SDK_RESPONSE_ERRO)
                error?.let {
                    val parameter = HashMap<String, Any>()
                    (it as Erro).apply {
                        parameter.put(SDK_PARAM_ID, this.id)
                        parameter.put(SDK_PARAM_CODE, this.codigo)
                        parameter.put(SDK_PARAM_DESCRIPTION, this.descricao)
                        val response = HashMap<String, Any>();
                        response.put(SDK_RESPONSE_IS_OK, false)
                        response.put(SDK_RESPONSE_ERROR, parameter)
                        pendingResult?.error(this.id, this.descricao, parameter)
                    }
                }
            } else {
                pendingResult?.error("-1", "erro generico", "generic error");
            }
            return true
        }
        return false
    }

    private fun transformBoundingBoxToMap(boundingBox: BoundingBox?): Map<String, Int> {
        val boundingBoxRet = mutableMapOf<String, Int>()

        boundingBox?.x?.let { boundingBoxRet.put(BOUNDING_BOX_X, it) };
        boundingBox?.y?.let { boundingBoxRet.put(BOUNDING_BOX_Y, it) };
        boundingBox?.width?.let { boundingBoxRet.put(BOUNDING_BOX_WIDTH, it) };
        boundingBox?.height?.let { boundingBoxRet.put(BOUNDING_BOX_HEIGHT, it) };

        return boundingBoxRet
    }

    override fun onAttachedToEngine(flutterPluginBinding: FlutterPluginBinding) {
        this.context = flutterPluginBinding.applicationContext
        channel = MethodChannel(flutterPluginBinding.binaryMessenger, CHANNEL)
        channel.setMethodCallHandler(this)
    }

    override fun onDetachedFromEngine(@NonNull binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
        this.context = null
    }

    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        activity = binding.activity
        binding.addActivityResultListener(this)
    }

    override fun onDetachedFromActivityForConfigChanges() {
        activity = null;
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        activity = binding.activity
        binding.addActivityResultListener(this)
    }

    override fun onDetachedFromActivity() {
        activity = null
    }

    private fun readableMapSelfieConfiguracaoTexto(configuracaoWritable: Map<String, String>?): ConfiguracaoTexto {
        configuracaoTexto = ConfiguracaoTexto()
        if (configuracaoWritable == null) return configuracaoTexto
        val fs: Array<Field> = configuracaoTexto::class.java.declaredFields
        for (field in fs) {
            try {
                val value: String? = configuracaoWritable[field.name]
                field.set(configuracaoTexto, value)
            } catch (e: IllegalAccessException) {
                e.printStackTrace()
            }
        }

        return configuracaoTexto
    }

    companion object {
        private const val SDK_PARAM_ID = "id"
        private const val SDK_PARAM_CODE = "codigo"
        private const val SDK_PARAM_DESCRIPTION = "descricao"
        private const val SDK_PARAM_TYPE = "tipo"
        private const val SDK_PARAM_SCORE = "score"
        private const val SDK_PARAM_BOUNDING_BOX = "boundingBox"
        private const val SDK_PARAM_IMAGE = "imagem"
        private const val BOUNDING_BOX_X = "x"
        private const val BOUNDING_BOX_Y = "y"
        private const val BOUNDING_BOX_WIDTH = "width"
        private const val BOUNDING_BOX_HEIGHT = "height"
        private const val SDK_PARAM_KEY = "key"
        private const val SDK_PARAM_RESOLUTION_ORIGINAL = "original"

        private const val SDK_PARAM_SSL_PINNING = "segurancaExtraSslPinning"
        private const val SDK_PARAM_CHAVE = "chave"
        private const val SDK_PARAM_WIZARD = "wizard"
        private const val SDK_PARAM_ACEITA_AB = "aceitaAB"
        private const val SDK_PARAM_LADO_DOCUMENTO_ACEITO = "ladoDocumentoAceito"

        private const val SDK_PARAM_TELA_CONFIRMACAO_SAIDA = "telaConfirmacaoDeSaida"
        private const val SDK_PARAM_TELA_SELECAO_DOCUMENTO = "telaSelecaoDocumento"
        private const val SDK_PARAM_CAPTURA_MANUAL = "capturaManual"
        private const val SDK_PARAM_ORIENTACAO_CAPTURA = "orientacaoCaptura"
        private const val SDK_PARAM_SCORE_MINIMO = "scoreMinimo"
        private const val SDK_PARAM_TENTATIVAS_CAPTURA = "tentativasDeCaptura"
        private const val SDK_PARAM_VERIFICAR_LUMINOSIDADE = "verificarLuminosidade"
        private const val SDK_PARAM_CROP_DOCUMENTO = "cropDocumento"
        private const val SDK_PARAM_VALIDA_DOCUMENTO = "validaDocumento"
        private const val SDK_PARAM_TIMEOUT_CAPTURA_MANUAL = "timeoutCapturaManual"
        private const val SDK_PARAM_TIPOS_DOCUMENTOS_ACEITOS = "tiposDocumentosAceitos"
        private const val SDK_PARAM_RESOLUCAO = "resolucao"
        private const val SDK_PARAM_CONFIGURACAO_TEXTO = "configuracaoTexto"
        private const val SDK_PARAM_RETORNAR_ERROS = "retornarErros"
        private const val SDK_PARAM_SEGURANCA_EXTRA_ROOT_CHECK = "segurancaExtraRootCheck"
        private const val SDK_PARAM_SEGURANCA_EXTRA_EMULATOR_CHECK = "segurancaExtraEmulatorCheck"
        private const val SDK_PARAM_RETURN_TYPE = "tipoRetorno"
        private const val SDK_PARAM_KEY_ENABLE_BUTTON_ATTEMPT = "tentativasExibicaoBotao"
        private const val SDK_PARAM_PLAY_CAPTURE_SOUND = "playCaptureSound"
        
        private const val SDK_RESPONSE_IS_OK = "isOk"
        private const val SDK_RESPONSE_ERROR = "error"
        private const val SDK_RESPONSE_LIST_OF_DOCUMENTS = "documentos"
        private const val SDK_RESPONSE_ERRO = "erro"

        private const val SDK_RESPONSE_CALLBACK_RESULT_CODE = "code"
        private const val SDK_RESPONSE_CALLBACK_RESULT_DESCRIPTION = "description"
        private const val SDK_RESPONSE_CALLBACK_RESULT_ID = "id"
        private const val SDK_RESPONSE_CALLBACK_RESULT_TIME = "time"
        private const val SDK_RESPONSE_CALLBACK_RESULT_TYPE = "type"
        private const val SDK_RESPONSE_CALLBACK_RESULT_DOC_TYPE = "docType"
        private const val SDK_RESPONSE_CALLBACK_RESULT_IMAGE = "image"

        private const val DART_TO_SDK_EVENT_START_CAPTURE = "startCapture"
        private const val DART_TO_SDK_EVENT_DOCUMENT_CALLBACK_LISTENER = "documentCallbackListener"

        private const val CODE_START_CAPTURE = 9689
        private const val CHANNEL = "serasa.idf/document"

        private const val LOG_TAG = "DocumentDetectorPlugin"
    }
}