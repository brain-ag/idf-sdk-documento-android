# brscan-sdk-react-native-demo

Utilizando tecnologias de Reconhecimento Facial, Machine Learning, Visão Computacional e Redes Neurais de aprendizagem a BrScan desenvolve sistemas que buscam aprimorar os processos de Onboarding Digital de fluxos de cadastro e autenticação de Clientes. A utilização destas soluções permite mitigar riscos de cadastros e identificar pessoas que possam estar tentado burlar processos de captura do documento de identificação. Neste repositório é possível obter a versão de demonstração e ter  uma visão técnica do processo de prova de vida, captura de selfie e captura do documento de identificação do cliente, suas dependências e seus meios de implementação em sistemas de terceiros.

Para o correto funcionamento do componente, o utilizador precisa estar conectado à internet com permissão de acesso ao BrFlow (https://www.brflow.com.br) e Liveness ( https://liveness.brscan.com.br). As requisições são realizadas usando o protocolo HTTPS e todo o processo de captura salva as imagens no diretório da aplicação, a remoção das imagens armazenadas no dispositivo após o uso é de responsabilidade do utilizador.

Abaixo serão apresentadas as dependências necessárias para o correto funcionamento dos componentes, exemplos e orientações de como instanciar o processo dentro de uma aplicação e munir o consumidor com um fluxo que detalha todas as integrações que são realizadas durante cada processo.

# Configuração de utilização do SDK

É necessário enviar a chave durante a incialização do componente. Para incluir a chave é necessário alterar o arquivo que se encontra no arquivo: src/App.tsx

`

 const documentConfig: DocumentConfig = {
         chave: '',// INSERT KEY HERE
        cropDocumento: true,
        validaDocumento: true,
        timeoutCapturaManual: 2,
        segurancaExtraRootCheck: true,// TO CHECK IF DEVICE IS RUNNING IN ROOT MODE (BY DEFAULT IS FALSE)
        segurancaExtraSslPinning: true,// TO VALIDATE REQUESTS WITH SSL PINNING (BY DEFAULT IS FALSE)
        segurancaExtraEmulatorCheck: true,// TO CHECK IF DEVICE IS A EMULATOR (BY DEFAULT IS FALSE)
        wizard: true,
        verificarLuminosidade: false,
        tiposDocumentosAceitos: ["cnh", "rg", "dni", "rnm", "rne", "cnhcel2022", "cnhdig2022", "outros"],
        aceitaAB: true,
        ladoDocumentoAceito: '',
        telaSelecaoDocumento: true,
        telaPreview: true,
        resolucao: 'low',
        tipoRetorno: 'base64',
        scoreMinimo: 70,
        retornarErros: false,
        capturaManual: false,
        telaConfirmacaoDeSaida: true,
        spoof: false,
        orientacaoCaptura: 'portrait',
        tentativasDeCaptura: 0,
        tokenTentativa: 0,
        customizacaoTexto: {
            brscan_documento_erro_digital_document_tamanho_excedido: "Arquivo selecionado maior que o tamanho permitido de 1MB.",
            brscan_documento_uploading_digital_file: "Estamos carregando seu documento digital",
            brscan_documento_uploading_digital_file_preparation: "Estamos preparando para receber seu arquivo",
            brscan_documento_loading: "Estamos carregando sua foto",
            brscan_documento_capture_image_loading_subtitle: "Estamos preparando para fotografar",
            brscan_documento_capture_loading_upload_validation_image_subtitle: "Estamos carregando sua foto",
            brscan_documento_captura_estado_aguardando_documento: "Aguardando documento",
            brscan_documento_captura_estado_encaixe_documento: "Encaixe o documento",
            brscan_documento_captura_estado_centralize_documento: "Centralize o documento",
            brscan_documento_captura_estado_aproxime_documento: "Aproxime o aparelho",
            brscan_documento_captura_estado_afaste_documento: "Afaste o aparelho",
            brscan_documento_captura_estado_aguarde: "Documento pronto para fotografar",
            brscan_documento_captura_frente_rg: "Frente do RG",
            brscan_documento_captura_verso_rg: "Verso do RG",
            brscan_documento_captura_rg_aberto: "RG Aberto",
            brscan_documento_captura_frente_cnh: "Frente da CNH",
            brscan_documento_captura_verso_cnh: "Verso da CNH",
            brscan_documento_captura_cnh_aberta: "CNH Aberta",
            brscan_documento_captura_frente_documento: "Frente do Documento",
            brscan_documento_captura_verso_documento: "Verso do Documento",
            brscan_documento_captura_documento_aberto: "Documento Aberto",
            brscan_documento_erro_conexao: "Erro ao conectar com o servidor, verifique sua conexão e tente novamente.",
            brscan_documento_erro_ao_validar_chave: "Erro ao validar chave. Por favor, verifique e tente novamente.",
            brscan_documento_erro_baixa_luminosidade: "Procure um ambiente com boa iluminação e tente novamente.",
            brscan_documento_erro_device_rooted: "A aplicação não suporta dispositivos em modo root.",
            brscan_documento_erro_usuario_cancelou_acao: "Ação cancelada pelo usuário.",
            brscan_documento_erro_processo: "Ocorreu uma falha ao concluir o processo. Por favor, tente novamente.",
            brscan_documento_erro_no_servidor: "Ocorreu uma falha na comunicação com o servidor. Por favor, tente novamente mais tarde.",
            brscan_documento_erro_ao_validar_imagem: "Não foi possível concluir a verificação. Por favor, tente novamente.",
            brscan_documento_erro_documento_nao_permitido: "Não foi possível concluir a verificação, documento não permitido.",
            brscan_documento_erro_nenhum_documento_encontrado: "Não foi possível identificar o documento. Por favor, tente novamente.",
            brscan_documento_erro_documento_diferente: "Esse lado pertence a um documento diferente do que foi fotografado antes. Por favor, fotografe os dois lados de um mesmo documento.",
            brscan_documento_erro_token_expired: "Por medidas de segurança, o tempo de sessão expirou, mas não se preocupe, você pode começar a confirmação novamente.",
            brscan_documento_erro_camera_indisponvel: "Não foi possível localizar a câmera do seu dispositivo.",
            brscan_documento_erro_lado_diferente_A: "Não foi possível concluir a verificação. Por favor, envie o lado com foto.",
            brscan_documento_erro_lado_diferente_B: "Não foi possível concluir a verificação. Por favor, envie o lado sem foto.",
            brscan_documento_erro_acesso_negado_title: "Acesso Negado",
            brscan_documento_erro_captura_camera_subtitle: "Precisamos ter acesso à sua câmera para realizar as fotos dos seus documentos.",
            brscan_documento_captura_camera_botao_de_acao: "Como liberar câmera",
            brscan_documento_erro_captura_title: "Algo deu errado por aqui!",
            brscan_documento_erro_captura_subtitle: "Encontramos um problema ao concluir  processo, por favor, tente novamente.",
            brscan_documento_erro_captura_botao_tentar_novamente: "Tentar novamente",
            brscan_documento_erro_captura_botao_sair_do_processo: "Sair do processo",
            brscan_confirma_documento_frente_title: "A foto da frente ficou boa?",
            brscan_confirma_documento_frente_subtitle: "Para dar sequência ao seu cadastro, a foto precisa estar nítida e de acordo com o documento selecionado. Só assim, ela pode ser aprovada.&#9786;",
            brscan_confirma_documento_verso_title: "A foto do verso ficou boa?",
            brscan_confirma_documento_verso_subtitle: "Para dar sequência ao seu cadastro, a foto precisa estar nítida e de acordo com o documento selecionado. Só assim, ela pode ser aprovada.&#9786;",
            brscan_confirma_documento_ambos_title: "A foto do documento completo ficou boa?",
            brscan_confirma_documento_ambos_subtitle: "Para dar sequência ao seu cadastro, a foto precisa estar nítida e de acordo com o documento selecionado. Só assim, ela pode ser aprovada.&#9786;",
            brscan_confirma_documento_continuar_botao_de_acao: "PRÓXIMO",
            brscan_confirma_documento_finalizar_botao_de_acao: "ENVIAR",
            brscan_confirma_documento_repetir_botao_de_acao: "TIRAR OUTRA",
            brscan_documento_proximo_processso_frente_title: "Agora vire o documento e fotografe o lado sem foto",
            brscan_documento_proximo_processso_verso_title: "Agora vire o documento e fotografe o lado com foto",
            brscan_documento_proximo_processso_botao_de_acao: "Entendi",
            brscan_documento_erro_device_emulated: "A aplicação não suporta dispositivos emulados.",
            brscan_documento_sucesso_foto_valida: "Sucesso ao validar Imagem.",
            brscan_documento_erro_tentativas_permitidas: "O usuário excedeu o número de tentativas permitidas.",
            brscan_documento_selecao_documentos_outros: "Outros documentos",
            brscan_documento_erro_digital_document: "Não foi possível confirmar o arquivo, documento enviado é inválido, por favor tente novamente.",
            brscan_documento_erro_journey_empty_protocols: "Não conseguimos concluir a ação, não há jornada a ser finalizada.",
            brscan_documento_selecao_cnh: "CNH",
            brscan_documento_selecao_cnh_digital: "CNH digital (CDT)",
            brscan_documento_selecao_documentos_nacionais: "RG, DNI ou CIN",
            brscan_documento_selecao_documentos_estrangeiros: "RNE ou RNM",
            brscan_documento_captura_fotografe_documento: "Fotografe o documento",
            brscan_documento_captura_vire_documento: "Fotografe o outro lado",
            brscan_documento_sucesso_botao_finalizar: "Continuar",
            brscan_documento_instruction_digital_document_title: "Envio da CNH digital",
            brscan_documento_instruction_digital_document_open_cdt: "Acesse o app Carteira Digital de Trânsito",
            brscan_documento_instruction_digital_document_export_cnh: "Exporte sua CNH digital em PDF",
            brscan_documento_instruction_digital_document_confirm_pdf: "Já tenho o arquivo em PDF",
            brscan_documento_instruction_digital_document_download_cdt: "Acessar aplicativo CDT<",
            brscan_documento_instruction_digital_document_return_document: "Retorne para enviar o documento",
            brscan_documento_instruction_digital_document_select_pdf_to_send: "Selecione o arquivo em PDF e envie",
            brscan_documento_digital_cnh_title: "Carteira digital de trânsito",
            brscan_documento_digital_cnh_export_subtitle: "Exporte o documento no formato PDF pelo aplicativo CDT e envie aqui",
            brscan_documento_digital_cnh_export_check_subtitle: "Confira o documento selecionado, deve ser enviado um arquivo único",
            brscan_documento_digital_send_file: "Enviar arquivo",
            brscan_documento_digital_cnh_back_instruction: "Voltar para instruções",
            brscan_documento_digital_cnh_file_size_error: "Arquivo selecionado maior \nque o tamanho permitido de 1MB",
            brscan_documento_digital_replace_file: "Substituir arquivo selecionado",
            brscan_documento_continue_sending_document_screen_title: "Continuar envio do documento",
            brscan_documento_continue_sending_document_title: "Bem-vindo de volta!",
            brscan_documento_continue_sending_document_subtitle: "É hora de enviar o arquivo da sua\nhabilitação digital em formato PDF",
            brscan_documento_continue_sending_document_btn_positive: "Continuar",
            brscan_documento_success_screen_title: "Tela de Sucesso",
            brscan_documento_erro_spoof: "Para concluir a validação é necessário fotografar um documento físico original. Não fotografe a tela de outro dispositivo.",
            brscan_documento_erro_opened_document: "Não foi possível validar a imagem do documento aberto. Por favor, fotografe um lado por vez.",
            brscan_documento_erro_closed_document: "Não foi possível validar a imagem. Por favor, fotografe o documento aberto."

        }

    }
```

Todos os parametros que são configuráveis durante a inicialização se encontram dentro da chamada no exemplo.

# Requisítos minimos

## Sistema operacional:
* Android 5 ou superior
* Iphone 11 ou superior

## Hardware:
* Câmera de 2MP com autofoco ou superior
* CPU armv8 ou superior
* Memória RAM 512MB ou superior
* Memória Interna com 512MB livre ou superior
* Resolução da tela de 1280x720 (HD) ou superior
* Conexão com internet
