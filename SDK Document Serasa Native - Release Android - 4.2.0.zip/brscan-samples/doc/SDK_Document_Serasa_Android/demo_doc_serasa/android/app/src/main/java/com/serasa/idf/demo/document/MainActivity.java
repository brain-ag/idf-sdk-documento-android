package com.serasa.idf.demo.document;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;

import br.com.brscan.sdk.captura.activities.DocumentoActivity;
import br.com.brscan.sdk.captura.handles.DocumentCallbackListener;
import br.com.brscan.sdk.captura.models.ConfiguracaoTexto;
import br.com.brscan.sdk.captura.models.Documento;
import br.com.brscan.sdk.captura.models.Erro;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private ActivityResultLauncher<Intent> someActivityResultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        someActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        Documento[] documents;
                        if (data != null) {
                            documents = (Documento[]) data.getSerializableExtra("documentos");
                            if (documents != null) {
                                Log.d(TAG, "documents: " + Arrays.toString(documents));
                                Toast.makeText(this, "Success", Toast.LENGTH_LONG).show();
                            } else {
                                Erro error = (Erro) data.getSerializableExtra("erro");
                                if (error != null) {
                                    Log.d(TAG, " error " + error);
                                    Toast.makeText(this, error.getDescricao(), Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                    }
                });

        Button btnActionCapture = findViewById(R.id.btn_action_capture);
        btnActionCapture.setOnClickListener(view -> startCapture());

    }


    private void startCapture() {
        Intent intent = new Intent(this, DocumentoActivity.class);

        intent.putExtra("chave", ""); // INSERT KEY HERE
        intent.putExtra("cropDocumento", true);
        intent.putExtra("validaDocumento", true);
        intent.putExtra("segurancaExtraRootCheck", true);// TO CHECK IF DEVICE IS RUNNING IN ROOT MODE (BY DEFAULT IS FALSE)
        intent.putExtra("segurancaExtraSslPinning", true);// TO VALIDATE REQUESTS WITH SSL PINNING (BY DEFAULT IS FALSE)
        intent.putExtra("segurancaExtraEmulatorCheck", true);// TO CHECK IF DEVICE IS A EMULATOR (BY DEFAULT IS FALSE)
        intent.putExtra("wizard", true);
        intent.putExtra("telaConfirmacaoDeSaida", true);
        intent.putExtra("verificarLuminosidade", false);
        intent.putExtra("tiposDocumentosAceitos", new String[]{ "cnh","rg", "dni", "rnm", "rne", "cnhcel2022", "cnhdig2022", "outros"});
        intent.putExtra("aceitaAB", false);
        intent.putExtra("ladoDocumentoAceito", "");
        intent.putExtra("telaSelecaoDocumento", true);
        intent.putExtra("telaPreview", true);
        intent.putExtra("resolucao", "low");
        intent.putExtra("tipoRetorno", "base64");
        intent.putExtra("scoreMinimo", 60);
        intent.putExtra("spoof", false);
        intent.putExtra("retornarErros", false);
        intent.putExtra("tokenTentativa", 0);
        intent.putExtra("capturaManual", false);
        intent.putExtra("tentativasDeCaptura", 0);
        intent.putExtra("tentativasExibicaoBotao", 3);
        intent.putExtra("playCaptureSound", false);
        intent.putExtra("spoofValidationExceptions", new String[]{ "cnhcel2022", "cin"});

        final ConfiguracaoTexto configuracaoTexto = new ConfiguracaoTexto();
        configuracaoTexto.brscan_documento_loading_title = "Aguarde um instante ...";
        /*
            ...
         */
        intent.putExtra("configuracaoTexto", configuracaoTexto);

        DocumentoActivity.documentCallbackListener = new DocumentCallbackListener() {
            @Override
            public void onCallback(JSONObject result) {

                try {
                    int codigo = result.getInt("code");
                    String id = result.getString("id");
                    String descricao = result.getString("description");
                    int tempoDeCaptura = result.getInt("time");
                    String tipoDeCaptura = result.getString("type");
                    String docType = result.getString("docType");
                    String image = result.getString("image");

                    Integer statusRequestCode = result.has("statusRequest") ? result.getInt("statusRequest") : null;

                    Log.d("CallbackListener", "Code: " + codigo);
                    Log.d("CallbackListener", "Id: " + id);
                    Log.d("CallbackListener", "Description: " + descricao);
                    Log.d("CallbackListener", "Capture Time: " + tempoDeCaptura);
                    Log.d("CallbackListener", "Type of Capture: " + tipoDeCaptura);
                    Log.d("CallbackListener", "DocType: " + docType);
                    Log.d("CallbackListener", "Image: " + image);

                    if (statusRequestCode != null) {
                        Log.d("CallbackListener", "StatusRequestCode: " + statusRequestCode);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

        someActivityResultLauncher.launch(intent);
    }


}