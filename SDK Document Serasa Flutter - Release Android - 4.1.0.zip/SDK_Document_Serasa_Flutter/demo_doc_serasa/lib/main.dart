import 'dart:async';
import 'package:flutter/material.dart';
import 'native_mode_serasa_idf_document_serasa.dart' as document_capture;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      restorationScopeId: "root",
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color.fromARGB(255, 0, 45, 209)),
        useMaterial3: true,
      ),
      home: const MyHomePage(
          title: 'Demo Document Capture', restorationId: 'resultRes'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage(
      {super.key, required this.title, required this.restorationId});

  final String restorationId;

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> with RestorationMixin {
  final RestorableString _resultRestorable =
      RestorableString('Unknown result.');

  @override
  String? get restorationId => widget.restorationId;

  Future _startCapture() async {
    var params = <String, Object>{};
    params[document_capture.keyChave] =
        ""; //INSIRA A CHAVE AQUI
    params[document_capture.keyWizard] = true;
    params[document_capture.keyAceitaAB] = false;
    params[document_capture.keyLadoDocumentoAceito] = "";
    params[document_capture.keyTelaConfirmacaoSaida] = true;
    params[document_capture.keyTelaSelecaoDocumento] = true;
    params[document_capture.keyCapturaManual] = false;
    params[document_capture.keyOrientacaoCaptura] = "portrait";
    params[document_capture.keyScoreMinimo] = 60;
    params[document_capture.keyTentativasCaptura] = 0;
    params[document_capture.keyTokenTentativa] = 0;
    params[document_capture.keyVerificarLuminosidade] = false;
    params[document_capture.keyCropDocumento] = true;
    params[document_capture.keyTimeoutCapturaManual] = 2.0;
    params[document_capture.keyTiposDocumentosAceitos] = <String>[
      'rg',
      'cin',
      'rnm',
      'cnh',
      'rne',
      'dni',
      'cnhdig',
      'cnhcel2022',
      'outros',
      'outrosdig'
    ];
    params[document_capture.keyResolucao] = "low";
    params[document_capture.keyRetornarErros] = false;
    params[document_capture.keySegurancaExtraRootCheck] = true;
    params[document_capture.keySegurancaExtraEmulatorCheck] = true;
    params[document_capture.keyValidaDocumento] = true;
    params[document_capture.keySegurancaExtraSslPinning] = true;
    params[document_capture.keyTipoRetorno] = "base64";
    params[document_capture.keyTelaPreview] = true;
    params[document_capture.keySpoof] = false;
    params[document_capture.keyTentativasExibicaoBotao] = 3;
    params[document_capture.keyPlayCaptureSound] = false;
    params[document_capture.keySpoofValidationExceptions] = <String>[
      'cnhcel2022',
      'cin'
    ];

    // Setting text configuration
    var configuracaoTextoParams = <String, String>{};

    configuracaoTextoParams[
            "brscan_documento_uploading_digital_file_subtitle"] =
        "Estamos carregando seu documento digital";
    configuracaoTextoParams[
            "brscan_documento_uploading_digital_file_preparation_subtitle"] =
        "Estamos preparando para receber seu arquivo";
    configuracaoTextoParams["brscan_documento_loading_title"] =
        "Aguarde um instante...";
    /**
    * 
    *     .... More configuration text params
    */

    params[document_capture.keyConfiguracaoTexto] = configuracaoTextoParams;
    document_capture.startCapture(
        params: params,
        onSuccess: (document) {
          // Callback Success

          debugPrint("--- Callback Success ---");

          debugPrint(
              "documents: ${document[document_capture.keyResultDocuments]}");

          setState(() {
            _resultRestorable.value = 'Success:\n ${document.toString()} ';
          });
        },
        onError: (error) {
          // Callback Error
          debugPrint("--- Callback Error ---");
          debugPrint("id: ${error[document_capture.keyResultId]}");
          debugPrint("codigo: ${error[document_capture.keyResultErrorCode]}");
          debugPrint(
              "descricao: ${error[document_capture.keyResultErrorDescription]}");

          setState(() {
            _resultRestorable.value = 'Result Error:\n ${error.toString()} ';
          });
        },
        onCallbackListener: (callbackListener) {
          // Callback callbackListener

          debugPrint("--- Callback callbackListener ---");

          debugPrint(
              "code: ${callbackListener[document_capture.keyResultCallbackCode]}");
          debugPrint(
              "description: ${callbackListener[document_capture.keyResultCallbackDescription]}");
          debugPrint(
              "id: ${callbackListener[document_capture.keyResultCallbackId]}");
          debugPrint(
              "time: ${callbackListener[document_capture.keyResultCallbackTime]}");
          debugPrint(
              "type: ${callbackListener[document_capture.keyResultCallbackType]}");
          debugPrint(
              "docType: ${callbackListener[document_capture.keyResultCallbackDocType]}");
          debugPrint(
              "image: ${callbackListener[document_capture.keyResultCallbackImage]}");

          var statusRequest =
              callbackListener[document_capture.keyResultCallbackStatusRequest];

          if (statusRequest != null) {
            debugPrint("statusRequest: $statusRequest");
          }
        });
  }

  @override
  void restoreState(RestorationBucket? oldBucket, bool initialRestore) {
    registerForRestoration(_resultRestorable, 'resultRes');
  }

  @override
  void dispose() {
    _resultRestorable.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.white,
        backgroundColor: const Color.fromARGB(255, 0, 45, 209),
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
          child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ElevatedButton(
                  onPressed: _startCapture,
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: const Color.fromARGB(
                        255, 0, 45, 209), // Background color
                  ),
                  child: const Text("Start Capture")),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                _resultRestorable.value,
                style: Theme.of(context).textTheme.headlineSmall,
              ),
            )
          ],
        ),
      )), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
