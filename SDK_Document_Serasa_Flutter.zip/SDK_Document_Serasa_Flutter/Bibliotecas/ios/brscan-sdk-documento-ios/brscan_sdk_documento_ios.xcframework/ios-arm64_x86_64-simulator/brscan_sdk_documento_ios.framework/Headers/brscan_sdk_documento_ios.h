//
//  brscan_sdk_documento_ios.h
//  brscan-sdk-documento-ios
//
//  Created by c93075a on 03/11/21.
//

#import <Foundation/Foundation.h>

//! Project version number for brscan_sdk_documento_ios.
FOUNDATION_EXPORT double brscan_sdk_documento_iosVersionNumber;

//! Project version string for brscan_sdk_documento_ios.
FOUNDATION_EXPORT const unsigned char brscan_sdk_documento_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <brscan_sdk_documento_ios/PublicHeader.h>
        

