import UIKit
import Flutter

@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
  private var eventSink: FlutterEventSink?

    
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        let resultObject = DocumentResult()
        GeneratedPluginRegistrant.register(with: self)
        
        guard let controller = window?.rootViewController as? FlutterViewController else {
            fatalError("rootViewController is not type FlutterViewController")
        }
        let navigationController = UINavigationController(rootViewController: controller)
        navigationController.isNavigationBarHidden = true
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
        
        let captureChannel = FlutterMethodChannel(name: "serasa.idf/document",
                                                  binaryMessenger: controller.binaryMessenger)
        captureChannel.setMethodCallHandler({(call: FlutterMethodCall, result: @escaping FlutterResult) -> Void in
            
            if call.method == "documentCallbackListener" {
                resultObject.resultCallbackListener = result
            }
            if call.method == "startCapture" {
                resultObject.result = result
                let arguments = call.arguments as! [String: Any]
                let capture = CapturaViewController(flutterResult: result, arguments: arguments, result: resultObject)
                controller.navigationController?.pushViewController(capture, animated: true)
            }
        })
        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
}

