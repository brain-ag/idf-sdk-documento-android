#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>
#import <brscan_sdk_documento_ios/brscan_sdk_documento_ios.h>
#import <React/RCTLog.h>
#import "AppDelegate.h"

#import <React/RCTModalHostView.h>
#import <React/RCTModalHostViewController.h>

NS_ASSUME_NONNULL_BEGIN

@interface SerasaIdfCaptureDocument : NSObject <RCTBridgeModule, CapturarDocumentoViewControllerDelegate, FinalizaJornadaCallbackDelegate>

@end

NS_ASSUME_NONNULL_END
