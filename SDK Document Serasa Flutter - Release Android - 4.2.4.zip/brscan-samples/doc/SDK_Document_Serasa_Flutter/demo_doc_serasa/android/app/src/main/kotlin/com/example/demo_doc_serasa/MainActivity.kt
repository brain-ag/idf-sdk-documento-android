package com.example.demo_doc_serasa

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugins.GeneratedPluginRegistrant
import serasa.idf.document.SerasaIdfDocumentDetectorPlugin

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        flutterEngine.plugins.add(SerasaIdfDocumentDetectorPlugin())
        GeneratedPluginRegistrant.registerWith(flutterEngine)
    }
}
