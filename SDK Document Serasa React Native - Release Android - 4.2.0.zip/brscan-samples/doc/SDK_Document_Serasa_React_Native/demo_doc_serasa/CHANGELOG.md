## [4.0.4] - 15-07-2024
- Melhoria: Atualização de versão lib sdk android documento para 4.0.4.
- Melhoria: Atualização de versão lib sdk ios documento para 4.0.3.

## [4.0.3] - 01-07-2024
- Melhoria: Atualização de versão lib sdk android documento para 4.0.3.
- Melhoria: Atualização de versão lib sdk ios documento para 4.0.2.

## [4.0.2] - 19-06-2024
- Melhoria: Atualização de versão lib sdk android documento para 4.0.2.

## [4.0.1] - 28-03-2024
- Melhoria: Atualização de versão lib sdk android documento para 4.0.1.
- Melhoria: Atualização de versão lib sdk ios documento para 4.0.1.

## [4.0.0] - 29-02-2024
- Melhoria: Atualização de versão lib sdk android documento para 4.0.0.
- Melhoria: Atualização de versão lib sdk ios documento para 4.0.0.

## [3.3.0] - 27-10-2023
- Melhoria: Atualização de versão lib sdk android documento para 3.3.0.
- Melhoria: Atualização de versão lib sdk ios documento para 3.3.0.

## [3.1.0] - 27-07-2023
- Melhoria: Atualização de versão lib sdk android documento para 3.1.0.

## [3.0.0] - 18-04-2023
- Melhoria: Atualização de versão lib sdk android documento para 3.0.0.
