#import "SerasaIdfCaptureDocument.h"
#include <math.h>

@implementation SerasaIdfCaptureDocument

RCTResponseSenderBlock success;
RCTResponseSenderBlock error;
RCTResponseSenderBlock documentCallbackListenerMain;
RCTResponseSenderBlock finalizarJornadaSucessoResult;
RCTResponseSenderBlock finalizarJornadaErroResult;

RCT_EXPORT_MODULE();

RCT_EXPORT_METHOD(captureDocumentCallBackListener:(RCTResponseSenderBlock)documentCallback) {
  @try {
    documentCallbackListenerMain = documentCallback;
    
  } @catch (NSError *exception) {
    documentCallback(@[exception]);
  }
}

RCT_EXPORT_METHOD(finishJourney:(NSString *)chave
                  segurancaExtraSslPinning:(BOOL *)segurancaExtraSslPinning
                  finalizarJornadaSucessoResult: (RCTResponseSenderBlock)finalizarJornadaSucesso
                  finalizarJornadaErroResult: (RCTResponseSenderBlock)finalizarJornadaErro)
{
 RCTLogInfo(@"Chave %@", chave);
  
  @try {
    finalizarJornadaSucessoResult = finalizarJornadaSucesso;
    finalizarJornadaErroResult = finalizarJornadaErro;
    
    FinalizaJornadaSDK *finalizaJornadaSDK = [[FinalizaJornadaSDK alloc] initWithChave:chave segurancaExtraSslPinning:segurancaExtraSslPinning];
    finalizaJornadaSDK.delegate = self;
  } @catch (NSError *exception) {
    finalizarJornadaErro(@[exception]);
  }
}

RCT_EXPORT_METHOD(
                  captureDocument:(NSString *)chave
                  cropDocumento:(BOOL *)cropDocumento
                  timeoutCapturaManual:(double)timeoutCapturaManual
                  wizard:(BOOL *)wizard
                  aceitaAB:(BOOL *)aceitaAB
                  tiposDocumentosAceitos:(NSArray *)tiposDocumentosAceitos
                  ladoDocumentoAceito:(NSString *)ladoDocumentoAceito
                  validaDocumento:(BOOL *)validaDocumento
                  segurancaExtraSslPinning:(BOOL *)segurancaExtraSslPinning
                  segurancaExtraRootCheck:(BOOL *)segurancaExtraRootCheck
                  verificarLuminosidade:(BOOL *)verificarLuminosidade
                  telaSelecaoDocumento:(BOOL *)telaSelecaoDocumento
                  telaPreview:(BOOL *)telaPreview
                  resolucao:(NSString *)resolucao
                  tipoRetorno:(NSString *)tipoRetorno
                  scoreMinimo:(double)scoreMinimo
                  customizacaoTexto:(NSDictionary *)customizacaoTexto
                  retornarErros:(BOOL *)retornarErros
                  segurancaExtraEmulatorCheck:(BOOL *)segurancaExtraEmulatorCheck
                  tokenTentativa:(double)tokenTentativa
                  capturaManual:(BOOL *)capturaManual
                  orientacaoCaptura:(NSString *)orientacaoCaptura
                  tentativasDeCaptura:(double)tentativasDeCaptura
                  telaConfirmacaoDeSaida:(BOOL *)telaConfirmacaoDeSaida
                  spoof:(BOOL *)spoof
                  tentativasExibicaoBotao:(double)tentativasExibicaoBotao
                  playCaptureSound:(BOOL *)playCaptureSound
                  spoofValidationExceptions:(NSArray *)spoofValidationExceptions
                  successCallback: (RCTResponseSenderBlock)successCallback
                  errorCallback: (RCTResponseSenderBlock)errorCallback)
{
  @try {
    success = successCallback;
    error = errorCallback;
    
    dispatch_async(dispatch_get_main_queue(), ^{
      ConfiguracaoTextoDocumento *configTexto = [[ConfiguracaoTextoDocumento alloc]
                                                 initWithBrscan_documento_error_upload_size_subtitle:[customizacaoTexto objectForKey:@"brscan_documento_error_upload_size_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_upload_size_subtitle"]: @""
                                                 brscan_documento_uploading_digital_file_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_uploading_digital_file_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_uploading_digital_file_subtitle"]: @""
                                                 brscan_documento_uploading_digital_file_preparation_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_uploading_digital_file_preparation_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_uploading_digital_file_preparation_subtitle"]: @""
                                                 brscan_documento_loading_title: [customizacaoTexto objectForKey:@"brscan_documento_loading_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_loading_title"]: @""
                                                 brscan_documento_capture_image_loading_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_capture_image_loading_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_capture_image_loading_subtitle"]: @""
                                                 brscan_documento_capture_loading_upload_validation_image_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_capture_loading_upload_validation_image_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_capture_loading_upload_validation_image_subtitle"]: @""
                                                 brscan_documento_captura_estado_aguardando_documento: [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_aguardando_documento"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_aguardando_documento"]: @""
                                                 brscan_documento_captura_estado_aproxime_documento: [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_aproxime_documento"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_aproxime_documento"]: @""
                                                 brscan_documento_captura_estado_afaste_documento: [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_afaste_documento"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_afaste_documento"]: @""
                                                 brscan_documento_captura_estado_aguarde: [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_aguarde"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_aguarde"]: @""
                                                 brscan_documento_captura_frente_rg: [customizacaoTexto objectForKey:@"brscan_documento_captura_frente_rg"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_frente_rg"]: @""
                                                 brscan_documento_captura_verso_rg: [customizacaoTexto objectForKey:@"brscan_documento_captura_verso_rg"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_verso_rg"]: @""
                                                 brscan_documento_captura_rg_aberto: [customizacaoTexto objectForKey:@"brscan_documento_captura_rg_aberto"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_rg_aberto"]: @""
                                                 brscan_documento_captura_frente_cnh: [customizacaoTexto objectForKey:@"brscan_documento_captura_frente_cnh"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_frente_cnh"]: @""
                                                 brscan_documento_captura_verso_cnh: [customizacaoTexto objectForKey:@"brscan_documento_captura_verso_cnh"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_verso_cnh"]: @""
                                                 brscan_documento_captura_cnh_aberta: [customizacaoTexto objectForKey:@"brscan_documento_captura_cnh_aberta"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_cnh_aberta"]: @""
                                                 brscan_documento_captura_frente_documento: [customizacaoTexto objectForKey:@"brscan_documento_captura_frente_documento"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_frente_documento"]: @""
                                                 brscan_documento_captura_verso_documento: [customizacaoTexto objectForKey:@"brscan_documento_captura_verso_documento"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_verso_documento"]: @""
                                                 brscan_documento_captura_documento_aberto: [customizacaoTexto objectForKey:@"brscan_documento_captura_documento_aberto"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_documento_aberto"]: @""
                                                 brscan_documento_error_connection_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_error_connection_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_connection_subtitle"]: @""
                                                 brscan_documento_erro_ao_validar_chave: [customizacaoTexto objectForKey:@"brscan_documento_erro_ao_validar_chave"] ? [customizacaoTexto objectForKey:@"brscan_documento_erro_ao_validar_chave"]: @""
                                                 brscan_documento_error_low_light_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_subtitle"]: @""
                                                 brscan_documento_erro_device_rooted: [customizacaoTexto objectForKey:@"brscan_documento_erro_device_rooted"] ? [customizacaoTexto objectForKey:@"brscan_documento_erro_device_rooted"]: @""
                                                 brscan_documento_erro_usuario_cancelou_acao: [customizacaoTexto objectForKey:@"brscan_documento_erro_usuario_cancelou_acao"] ? [customizacaoTexto objectForKey:@"brscan_documento_erro_usuario_cancelou_acao"]: @""
                                                 brscan_documento_error_proccess_not_completed_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_error_proccess_not_completed_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_proccess_not_completed_subtitle"]: @""
                                                 brscan_documento_error_connection_failed_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_error_connection_failed_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_connection_failed_subtitle"]: @""
                                                 brscan_documento_error_image_validate_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_error_image_validate_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_image_validate_subtitle"]: @""
                                                 brscan_documento_error_invalid_document_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_error_invalid_document_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_invalid_document_subtitle"]: @""
                                                 brscan_documento_erro_nenhum_documento_encontrado: [customizacaoTexto objectForKey:@"brscan_documento_error_different_document_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_different_document_subtitle"]: @""
                                                 brscan_documento_error_different_document_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_error_token_expired_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_token_expired_subtitle"]: @""
                                                 brscan_documento_error_token_expired_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_erro_camera_indisponvel"] ? [customizacaoTexto objectForKey:@"brscan_documento_erro_camera_indisponvel"]: @""
                                                 brscan_documento_erro_camera_indisponvel: [customizacaoTexto objectForKey:@"brscan_documento_error_different_side_A_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_different_side_A_subtitle"]: @""
                                                 brscan_documento_error_different_side_A_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_error_different_side_B_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_different_side_B_subtitle"]: @""
                                                 brscan_documento_error_different_side_B_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_erro_acesso_negado_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_erro_acesso_negado_title"]: @""
                                                 brscan_documento_erro_acesso_negado_title: [customizacaoTexto objectForKey:@"brscan_documento_error_enable_camera_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_enable_camera_subtitle"]: @""
                                                 brscan_documento_error_enable_camera_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_captura_camera_botao_de_acao"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_camera_botao_de_acao"]: @""
                                                 brscan_documento_captura_camera_botao_de_acao: [customizacaoTexto objectForKey:@"brscan_documento_erro_captura_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_erro_captura_title"]: @""
                                                 brscan_documento_erro_captura_title: [customizacaoTexto objectForKey:@"brscan_documento_erro_captura_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_erro_captura_subtitle"]: @""
                                                 brscan_documento_erro_captura_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_error_button_try_again"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_button_try_again"]: @""
                                                 brscan_documento_error_button_try_again: [customizacaoTexto objectForKey:@"brscan_documento_erro_captura_botao_sair_do_processo"] ? [customizacaoTexto objectForKey:@"brscan_documento_erro_captura_botao_sair_do_processo"]: @""
                                                 brscan_documento_erro_captura_botao_sair_do_processo: [customizacaoTexto objectForKey:@"brscan_confirma_documento_frente_title"] ? [customizacaoTexto objectForKey:@"brscan_confirma_documento_frente_title"]: @""
                                                 brscan_confirma_documento_frente_title: [customizacaoTexto objectForKey:@"brscan_confirma_documento_frente_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_confirma_documento_frente_subtitle"]: @""
                                                 brscan_confirma_documento_frente_subtitle: [customizacaoTexto objectForKey:@"brscan_confirma_documento_verso_title"] ? [customizacaoTexto objectForKey:@"brscan_confirma_documento_verso_title"]: @""
                                                 brscan_confirma_documento_verso_title: [customizacaoTexto objectForKey:@"brscan_confirma_documento_verso_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_confirma_documento_verso_subtitle"]: @""
                                                 brscan_confirma_documento_verso_subtitle: [customizacaoTexto objectForKey:@"brscan_confirma_documento_ambos_title"] ? [customizacaoTexto objectForKey:@"brscan_confirma_documento_ambos_title"]: @""
                                                 brscan_confirma_documento_ambos_title: [customizacaoTexto objectForKey:@"brscan_confirma_documento_ambos_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_confirma_documento_ambos_subtitle"]: @""
                                                 brscan_confirma_documento_ambos_subtitle: [customizacaoTexto objectForKey:@"brscan_confirma_documento_continuar_botao_de_acao"] ? [customizacaoTexto objectForKey:@"brscan_confirma_documento_continuar_botao_de_acao"]: @""
                                                 brscan_confirma_documento_continuar_botao_de_acao: [customizacaoTexto objectForKey:@"brscan_confirma_documento_finalizar_botao_de_acao"] ? [customizacaoTexto objectForKey:@"brscan_confirma_documento_finalizar_botao_de_acao"]: @""
                                                 brscan_confirma_documento_finalizar_botao_de_acao: [customizacaoTexto objectForKey:@"brscan_confirma_documento_repetir_botao_de_acao"] ? [customizacaoTexto objectForKey:@"brscan_confirma_documento_repetir_botao_de_acao"]: @""
                                                 brscan_confirma_documento_repetir_botao_de_acao: [customizacaoTexto objectForKey:@"brscan_documento_proximo_processso_frente_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_proximo_processso_frente_title"]: @""
                                                 brscan_documento_proximo_processso_frente_title: [customizacaoTexto objectForKey:@"brscan_documento_proximo_processso_verso_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_proximo_processso_verso_title"]: @""
                                                 brscan_documento_proximo_processso_verso_title: [customizacaoTexto objectForKey:@"brscan_documento_proximo_processso_botao_de_acao"] ? [customizacaoTexto objectForKey:@"brscan_documento_proximo_processso_botao_de_acao"]: @""
                                                 brscan_documento_proximo_processso_botao_de_acao: [customizacaoTexto objectForKey:@"brscan_documento_sucesso_foto_valida"] ? [customizacaoTexto objectForKey:@"brscan_documento_sucesso_foto_valida"]: @""
                                                 brscan_documento_erro_device_emulated: [customizacaoTexto objectForKey:@"brscan_documento_erro_tentativas_permitidas"] ? [customizacaoTexto objectForKey:@"brscan_documento_erro_tentativas_permitidas"]: @""
                                                 brscan_documento_sucesso_foto_valida: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_others_documents"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_others_documents"]: @""
                                                 brscan_documento_erro_tentativas_permitidas: [customizacaoTexto objectForKey:@"brscan_documento_error_invalid_file_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_invalid_file_subtitle"]: @""
                                                 brscan_documento_choose_document_others_documents: [customizacaoTexto objectForKey:@"brscan_documento_erro_journey_empty_protocols"] ? [customizacaoTexto objectForKey:@"brscan_documento_erro_journey_empty_protocols"]: @""
                                                 brscan_documento_error_invalid_file_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_cnh_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_cnh_title"]: @""
                                                 brscan_documento_erro_journey_empty_protocols: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_cdt_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_cdt_title"]: @""
                                                 brscan_documento_choose_document_cnh_title: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_rg_dni_cin_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_rg_dni_cin_title"]: @""
                                                 brscan_documento_choose_document_cdt_title: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_rne_rnm_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_rne_rnm_title"]: @""
                                                 brscan_documento_choose_document_rg_dni_cin_title: [customizacaoTexto objectForKey:@"brscan_documento_captura_fotografe_documento"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_fotografe_documento"]: @""
                                                 brscan_documento_choose_document_rne_rnm_title: [customizacaoTexto objectForKey:@"brscan_documento_captura_vire_documento"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_vire_documento"]: @""
                                                 brscan_documento_captura_fotografe_documento: [customizacaoTexto objectForKey:@"brscan_documento_sucesso_botao_finalizar"] ? [customizacaoTexto objectForKey:@"brscan_documento_sucesso_botao_finalizar"]: @""
                                                 brscan_documento_captura_vire_documento: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_rg_dni_cin_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_rg_dni_cin_subtitle"]: @""
                                                 brscan_documento_sucesso_botao_finalizar: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_rne_rnm_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_rne_rnm_subtitle"]: @""
                                                 brscan_documento_choose_document_rg_dni_cin_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_cnh_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_cnh_subtitle"]: @""
                                                 brscan_documento_choose_document_rne_rnm_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_cdt_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_cdt_subtitle"]: @""
                                                 brscan_documento_choose_document_cnh_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_others_documents_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_others_documents_subtitle"]: @""
                                                 brscan_documento_choose_document_cdt_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_title"]: @""
                                                 brscan_documento_choose_document_others_documents_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_subtitle"]: @""
                                                 brscan_documento_instruction_digital_document_title: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_one"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_one"]: @""
                                                 brscan_documento_instruction_digital_document_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_two"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_two"]: @""
                                                 brscan_documento_instruction_digital_document_one: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_three"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_three"]: @""
                                                 brscan_documento_instruction_digital_document_two: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_four"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_four"]: @""
                                                 brscan_documento_instruction_digital_document_three: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_five"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_five"]: @""
                                                 brscan_documento_instruction_digital_document_four: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_six"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_six"]: @""
                                                 brscan_documento_instruction_digital_document_five: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_open_cdt"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_open_cdt"]: @""
                                                 brscan_documento_instruction_digital_document_six: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_export_cnh"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_export_cnh"]: @""
                                                 brscan_documento_instruction_digital_document_open_cdt: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_confirm_pdf"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_confirm_pdf"]: @""
                                                 brscan_documento_instruction_digital_document_export_cnh: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_download_cdt"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_download_cdt"]: @""
                                                 brscan_documento_instruction_digital_document_confirm_pdf: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_return_document"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_return_document"]: @""
                                                 brscan_documento_instruction_digital_document_download_cdt: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_select_pdf_to_send"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_select_pdf_to_send"]: @""
                                                 brscan_documento_instruction_digital_document_return_document: [customizacaoTexto objectForKey:@"brscan_documento_select_digital_document_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_select_digital_document_title"]: @""
                                                 brscan_documento_instruction_digital_document_select_pdf_to_send: [customizacaoTexto objectForKey:@"brscan_documento_select_digital_document_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_select_digital_document_subtitle"]: @""
                                                 brscan_documento_select_digital_document_title: [customizacaoTexto objectForKey:@"brscan_documento_digital_cnh_export_check_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_digital_cnh_export_check_subtitle"]: @""
                                                 brscan_documento_select_digital_document_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_select_digital_document_send_file"] ? [customizacaoTexto objectForKey:@"brscan_documento_select_digital_document_send_file"]: @""
                                                 brscan_documento_digital_cnh_export_check_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_send_file"] ? [customizacaoTexto objectForKey:@"brscan_documento_instruction_digital_document_send_file"]: @""
                                                 brscan_documento_select_digital_document_send_file: [customizacaoTexto objectForKey:@"brscan_documento_select_digital_document_how_to_export"] ? [customizacaoTexto objectForKey:@"brscan_documento_select_digital_document_how_to_export"]: @""
                                                 brscan_documento_instruction_digital_document_send_file: [customizacaoTexto objectForKey:@"brscan_documento_digital_cnh_file_size_error"] ? [customizacaoTexto objectForKey:@"brscan_documento_digital_cnh_file_size_error"]: @""
                                                 brscan_documento_select_digital_document_how_to_export: [customizacaoTexto objectForKey:@"brscan_documento_digital_replace_file"] ? [customizacaoTexto objectForKey:@"brscan_documento_digital_replace_file"]: @""
                                                 brscan_documento_digital_cnh_file_size_error: [customizacaoTexto objectForKey:@"brscan_documento_select_digital_document_send_other_file"] ? [customizacaoTexto objectForKey:@"brscan_documento_select_digital_document_send_other_file"]: @""
                                                 brscan_documento_digital_replace_file: [customizacaoTexto objectForKey:@"brscan_documento_continue_sending_document_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_continue_sending_document_title"]: @""
                                                 brscan_documento_select_digital_document_send_other_file: [customizacaoTexto objectForKey:@"brscan_documento_continue_sending_document_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_continue_sending_document_subtitle"]: @""
                                                 brscan_documento_continue_sending_document_title: [customizacaoTexto objectForKey:@"brscan_documento_continue_sending_document_btn_positive"] ? [customizacaoTexto objectForKey:@"brscan_documento_continue_sending_document_btn_positive"]: @""
                                                 brscan_documento_continue_sending_document_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_continue_sending_document_btn_back_instructions"] ? [customizacaoTexto objectForKey:@"brscan_documento_continue_sending_document_btn_back_instructions"]: @""
                                                 brscan_documento_continue_sending_document_btn_positive: [customizacaoTexto objectForKey:@"brscan_documento_success_screen_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_success_screen_title"]: @""
                                                 brscan_documento_continue_sending_document_btn_back_instructions: [customizacaoTexto objectForKey:@"brscan_documento_error_spoof_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_spoof_subtitle"]: @""
                                                 brscan_documento_success_screen_title: [customizacaoTexto objectForKey:@"brscan_documento_error_opened_document_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_opened_document_subtitle"]: @""
                                                 brscan_documento_error_spoof_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_error_closed_document_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_closed_document_subtitle"]: @""
                                                 brscan_documento_error_opened_document_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_mova_para_a_esquerda"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_mova_para_a_esquerda"]: @""
                                                 brscan_documento_error_closed_document_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_mova_para_a_direita"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_mova_para_a_direita"]: @""
                                                 brscan_documento_captura_estado_mova_para_a_esquerda: [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_mova_para_a_cima"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_mova_para_a_cima"]: @""
                                                 brscan_documento_captura_estado_mova_para_a_direita: [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_mova_para_a_baixo"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_mova_para_a_baixo"]: @""
                                                 brscan_documento_captura_estado_mova_para_a_cima: [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_documentos_na_horizontal"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_documentos_na_horizontal"]: @""
                                                 brscan_documento_captura_estado_mova_para_a_baixo: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_title"]: @""
                                                 brscan_documento_captura_estado_documentos_na_horizontal: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_physical_radio_button_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_physical_radio_button_title"]: @""
                                                 brscan_documento_choose_document_title: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_digital_radio_button_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_digital_radio_button_title"]: @""
                                                 brscan_documento_choose_document_physical_radio_button_title: [customizacaoTexto objectForKey:@"brscan_documento_choose_document_btn_positive"] ? [customizacaoTexto objectForKey:@"brscan_documento_choose_document_btn_positive"]: @""
                                                 brscan_documento_choose_document_digital_radio_button_title: [customizacaoTexto objectForKey:@"brscan_documento_preview_btn_positive"] ? [customizacaoTexto objectForKey:@"brscan_documento_preview_btn_positive"]: @""
                                                 brscan_documento_choose_document_btn_positive: [customizacaoTexto objectForKey:@"brscan_documento_preview_take_another_picture"] ? [customizacaoTexto objectForKey:@"brscan_documento_preview_take_another_picture"]: @""
                                                 brscan_documento_preview_btn_positive: [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_title"]: @""
                                                 brscan_documento_preview_take_another_picture: [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_subtitle"]: @""
                                                 brscan_documento_capture_instruction_title: [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_one"] ? [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_one"]: @""
                                                 brscan_documento_capture_instruction_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_two"] ? [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_two"]: @""
                                                 brscan_documento_capture_instruction_one: [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_three"] ? [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_three"]: @""
                                                 brscan_documento_capture_instruction_two: [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_four"] ? [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_four"]: @""
                                                 brscan_documento_capture_instruction_three: [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_btn_positive"] ? [customizacaoTexto objectForKey:@"brscan_documento_capture_instruction_btn_positive"]: @""
                                                 brscan_documento_capture_instruction_four: [customizacaoTexto objectForKey:@"brscan_documento_error_connection_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_connection_title"]: @""
                                                 brscan_documento_capture_instruction_btn_positive: [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_title"]: @""
                                                 brscan_documento_error_connection_title: [customizacaoTexto objectForKey:@"brscan_documento_error_enable_camera_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_enable_camera_title"]: @""
                                                 brscan_documento_error_low_light_title: [customizacaoTexto objectForKey:@"brscan_documento_error_connection_failed_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_connection_failed_title"]: @""
                                                 brscan_documento_error_enable_camera_title: [customizacaoTexto objectForKey:@"brscan_documento_error_proccess_not_completed_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_proccess_not_completed_title"]: @""
                                                 brscan_documento_error_connection_failed_title: [customizacaoTexto objectForKey:@"brscan_documento_error_image_validate_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_image_validate_title"]: @""
                                                 brscan_documento_error_proccess_not_completed_title: [customizacaoTexto objectForKey:@"brscan_documento_error_invalid_document_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_invalid_document_title"]: @""
                                                 brscan_documento_error_image_validate_title: [customizacaoTexto objectForKey:@"brscan_documento_error_different_document_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_different_document_title"]: @""
                                                 brscan_documento_error_invalid_document_title: [customizacaoTexto objectForKey:@"brscan_documento_error_no_document_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_no_document_title"]: @""
                                                 brscan_documento_error_different_document_title: [customizacaoTexto objectForKey:@"brscan_documento_error_different_side_A_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_different_side_A_title"]: @""
                                                 brscan_documento_error_no_document_title: [customizacaoTexto objectForKey:@"brscan_documento_error_different_side_B_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_different_side_B_title"]: @""
                                                 brscan_documento_error_different_side_A_title: [customizacaoTexto objectForKey:@"brscan_documento_error_token_expired_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_token_expired_title"]: @""
                                                 brscan_documento_error_different_side_B_title: [customizacaoTexto objectForKey:@"brscan_documento_error_opened_document_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_opened_document_title"]: @""
                                                 brscan_documento_error_token_expired_title: [customizacaoTexto objectForKey:@"brscan_documento_error_closed_document_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_closed_document_title"]: @""
                                                 brscan_documento_error_opened_document_title: [customizacaoTexto objectForKey:@"brscan_documento_error_spoof_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_spoof_title"]: @""
                                                 brscan_documento_error_closed_document_title: [customizacaoTexto objectForKey:@"brscan_documento_error_upload_size_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_upload_size_title"]: @""
                                                 brscan_documento_error_spoof_title: [customizacaoTexto objectForKey:@"brscan_documento_error_invalid_file_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_invalid_file_title"]: @""
                                                 brscan_documento_error_upload_size_title: [customizacaoTexto objectForKey:@"brscan_documento_invalid_document_instruction_one"] ? [customizacaoTexto objectForKey:@"brscan_documento_invalid_document_instruction_one"]: @""
                                                 brscan_documento_error_invalid_file_title: [customizacaoTexto objectForKey:@"brscan_documento_invalid_document_instruction_two"] ? [customizacaoTexto objectForKey:@"brscan_documento_invalid_document_instruction_two"]: @""
                                                 brscan_documento_invalid_document_instruction_one: [customizacaoTexto objectForKey:@"brscan_documento_invalid_document_instruction_three"] ? [customizacaoTexto objectForKey:@"brscan_documento_invalid_document_instruction_three"]: @""
                                                 brscan_documento_invalid_document_instruction_two: [customizacaoTexto objectForKey:@"brscan_documento_no_document_instruction_one"] ? [customizacaoTexto objectForKey:@"brscan_documento_no_document_instruction_one"]: @""
                                                 brscan_documento_invalid_document_instruction_three: [customizacaoTexto objectForKey:@"brscan_documento_no_document_instruction_two"] ? [customizacaoTexto objectForKey:@"brscan_documento_no_document_instruction_two"]: @""
                                                 brscan_documento_no_document_instruction_one: [customizacaoTexto objectForKey:@"brscan_documento_no_document_instruction_three"] ? [customizacaoTexto objectForKey:@"brscan_documento_no_document_instruction_three"]: @""
                                                 brscan_documento_no_document_instruction_two: [customizacaoTexto objectForKey:@"brscan_documento_image_validate_instruction_one"] ? [customizacaoTexto objectForKey:@"brscan_documento_image_validate_instruction_one"]: @""
                                                 brscan_documento_no_document_instruction_three: [customizacaoTexto objectForKey:@"brscan_documento_image_validate_instruction_two"] ? [customizacaoTexto objectForKey:@"brscan_documento_image_validate_instruction_two"]: @""
                                                 brscan_documento_image_validate_instruction_one: [customizacaoTexto objectForKey:@"brscan_documento_image_validate_instruction_three"] ? [customizacaoTexto objectForKey:@"brscan_documento_image_validate_instruction_three"]: @""
                                                 brscan_documento_image_validate_instruction_two: [customizacaoTexto objectForKey:@"brscan_documento_image_validate_instruction_four"] ? [customizacaoTexto objectForKey:@"brscan_documento_image_validate_instruction_four"]: @""
                                                 brscan_documento_image_validate_instruction_three: [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_instruction_one"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_instruction_one"]: @""
                                                 brscan_documento_image_validate_instruction_four: [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_instruction_two"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_instruction_two"]: @""
                                                 brscan_documento_error_low_light_instruction_one: [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_instruction_three"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_instruction_three"]: @""
                                                 brscan_documento_error_low_light_instruction_two: [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_instruction_four"] ? [customizacaoTexto objectForKey:@"brscan_documento_error_low_light_instruction_four"]: @""
                                                 brscan_documento_error_low_light_instruction_three: [customizacaoTexto objectForKey:@"brscan_documento_exit_confirmation_title"] ? [customizacaoTexto objectForKey:@"brscan_documento_exit_confirmation_title"]: @""
                                                 brscan_documento_error_low_light_instruction_four: [customizacaoTexto objectForKey:@"brscan_documento_exit_confirmation_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_exit_confirmation_subtitle"]: @""
                                                 brscan_documento_exit_confirmation_title: [customizacaoTexto objectForKey:@"brscan_documento_exit_confirmation_button_positive"] ? [customizacaoTexto objectForKey:@"brscan_documento_exit_confirmation_button_positive"]: @""
                                                 brscan_documento_exit_confirmation_subtitle: [customizacaoTexto objectForKey:@"brscan_documento_exit_confirmation_button_negative"] ? [customizacaoTexto objectForKey:@"brscan_documento_exit_confirmation_button_negative"]: @""
                                                 brscan_documento_exit_confirmation_button_positive: [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_inicial"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_inicial"]: @""
                                                 brscan_documento_exit_confirmation_button_negative: [customizacaoTexto objectForKey:@"brscan_documento_captura_expect_side_b"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_expect_side_b"]: @""
                                                 brscan_documento_captura_estado_inicial: [customizacaoTexto objectForKey:@"brscan_documento_captura_expect_side_a"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_expect_side_a"]: @""
                                                 brscan_documento_captura_expect_side_b: [customizacaoTexto objectForKey:@"brscan_documento_captura_documento_lado_b"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_documento_lado_b"]: @""
                                                 brscan_documento_captura_expect_side_a: [customizacaoTexto objectForKey:@"brscan_documento_captura_documento_lado_a"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_documento_lado_a"]: @""
                                                 brscan_documento_captura_documento_lado_b: [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_documentos_aceitos"] ? [customizacaoTexto objectForKey:@"brscan_documento_captura_estado_documentos_aceitos"]: @""
                                                 brscan_documento_captura_documento_lado_a: [customizacaoTexto objectForKey:@"brscan_documento_uploading_digital_file_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_uploading_digital_file_subtitle"]: @""
                                                 brscan_documento_captura_estado_documentos_aceitos: [customizacaoTexto objectForKey:@"brscan_documento_uploading_digital_file_preparation_subtitle"] ? [customizacaoTexto objectForKey:@"brscan_documento_uploading_digital_file_preparation_subtitle"]: @""
                                                 
      ];
      
      
      
      
      CapturarDocumentoViewController *controller = [[CapturarDocumentoViewController alloc] initWithChave:chave cropDocumento:cropDocumento validaDocumento:validaDocumento wizard:wizard aceitaAB:aceitaAB tiposDocumentosAceitos:tiposDocumentosAceitos segurancaExtraSslPinning:segurancaExtraSslPinning segurancaExtraRootCheck:segurancaExtraRootCheck timeoutCapturaManual:timeoutCapturaManual telaSelecaoDocumento:telaSelecaoDocumento resolucao:resolucao ladoDocumentoAceito:ladoDocumentoAceito tipoRetorno:tipoRetorno telaPreview:telaPreview scoreMinimo:scoreMinimo customizacaoTexto:configTexto retornarErros:retornarErros verificarLuminosidade:verificarLuminosidade segurancaExtraEmulatorCheck:segurancaExtraEmulatorCheck tokenTentativa:tokenTentativa orientacaoCaptura:orientacaoCaptura capturaManual:capturaManual tentativasDeCaptura:tentativasDeCaptura telaConfirmacaoDeSaida:telaConfirmacaoDeSaida spoof:spoof tentativasExibicaoBotao:tentativasExibicaoBotao playCaptureSound:playCaptureSound spoofValidationExceptions:spoofValidationExceptions];
      
      controller.delegate = self;
      UINavigationController* appNavigator = [[UINavigationController alloc] initWithRootViewController:controller];
      [appNavigator setModalPresentationStyle:UIModalPresentationFullScreen];
      appNavigator.navigationBarHidden = true;
      UIViewController *topController = [[[[UIApplication sharedApplication] delegate] window] rootViewController];
      [topController presentViewController:appNavigator animated:NO completion:nil];
    });
  } @catch (NSError *exception) {
    errorCallback(@[exception]);
  }
}

- (NSString *)convertImageToBase64:(NSString *)path {
  UIImage *image =  [UIImage imageWithContentsOfFile:path];
  NSData *imageData = UIImageJPEGRepresentation(image, 1.0);
  NSString *base64 = [imageData base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
  return base64;
}

- (NSArray<NSDictionary<NSString *,id> *> *)serializeResponse:(NSArray<NSDictionary<NSString *,id> *> *)documetos {
  NSMutableArray<NSDictionary<NSString *,id> *> *data = [NSMutableArray new];
  
  for (NSDictionary<NSString *,id> *doc in documetos) {
    if (![[doc objectForKey:@"imagem"] isEqualToString:@""] ){
    
    NSDictionary *dic = @{
      @"imagem": [doc objectForKey:@"imagem"],
      @"tipo": [doc objectForKey:@"tipo"],
      @"score": [doc objectForKey:@"score"],
      @"boundingBox": [doc objectForKey:@"boundingBox"],
      @"id": [doc objectForKey:@"id"],
    };
    
    [data addObject:dic];
    }
  };

  return data;
}

- (void)closeCapture {
  AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
  [delegate.window.rootViewController dismissViewControllerAnimated:NO completion:nil];
}

- (void)erro:(NSDictionary<NSString *,id> *)erro {
  NSDictionary *dicErroDoc = @{
    @"codigo": [erro objectForKey:@"codigo"],
    @"descricao": [erro objectForKey:@"descricao"],
    @"id": [erro objectForKey:@"id"],
  };
  error(@[dicErroDoc]);
  [self closeCapture];
  
}

- (void)sucesso:(NSArray<NSDictionary<NSString *,id> *> * _Nonnull)documento {
  NSArray<NSDictionary<NSString *, id> *> *documentosSeialized = [self serializeResponse:documento];
    success(@[documentosSeialized]);
    [self closeCapture];
}

- (void)documentCallbackListener:(NSDictionary<NSString *,id> * _Nonnull)documentCallback {
  NSDictionary *dicCallback;
  if ([documentCallback objectForKey:@"statusRequest"]) {
    dicCallback = @{
      @"code": [documentCallback objectForKey:@"code"],
      @"description": [documentCallback objectForKey:@"description"],
      @"id": [documentCallback objectForKey:@"id"],
      @"time": [documentCallback objectForKey:@"time"],
      @"type": [documentCallback objectForKey:@"type"],
      @"docType": [documentCallback objectForKey:@"docType"],
      @"image": [documentCallback objectForKey:@"image"],
      @"statusRequest": [documentCallback objectForKey:@"statusRequest"],
    };
  } else {
    dicCallback = @{
      @"code": [documentCallback objectForKey:@"code"],
      @"description": [documentCallback objectForKey:@"description"],
      @"id": [documentCallback objectForKey:@"id"],
      @"time": [documentCallback objectForKey:@"time"],
      @"type": [documentCallback objectForKey:@"type"],
      @"docType": [documentCallback objectForKey:@"docType"],
      @"image": [documentCallback objectForKey:@"image"],
    };
  }
  
  documentCallbackListenerMain(@[dicCallback]);
}

- (void)erroFinalizarWithResultadoErro:(NSDictionary<NSString *,id> * _Nonnull)resultadoErro {
  NSDictionary *dicErroFinalizar = @{
    @"descricao": [resultadoErro objectForKey:@"descricao"],
    @"codigo": [resultadoErro objectForKey:@"codigo"],
  };
  finalizarJornadaErroResult(@[dicErroFinalizar]);
}

- (void)sucessoFinalizarWithResultadoSucesso:(NSDictionary<NSString *,id> * _Nonnull)resultadoSucesso {
  NSDictionary *dicSucessoFinalizar = @{
    @"id": [resultadoSucesso objectForKey:@"id"],
  };
  finalizarJornadaSucessoResult(@[dicSucessoFinalizar]);
}

@end

