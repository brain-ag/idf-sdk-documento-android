import UIKit
import Flutter
import brscan_sdk_documento_ios

class CapturaViewController: UIViewController {
    var flutterResult: FlutterResult
    var result: DocumentResult
    var arguments: [String: Any]
    
    init(flutterResult: @escaping FlutterResult, arguments: [String: Any], result: DocumentResult) {
        self.flutterResult = flutterResult
        self.arguments = arguments
        self.result = result
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func start() {
        
        let chave = arguments["chave"] as? String ?? ""
        let cropDocumento = arguments["cropDocumento"] as? Bool ?? false
        let validaDocumento = arguments["validaDocumento"] as? Bool ?? false
        let wizard = arguments["wizard"] as? Bool ?? false
        let aceitaAB = arguments["aceitaAB"] as? Bool ?? false
        let tiposDocumentosAceitos = arguments["tiposDocumentosAceitos"] as? [String] ?? [""]
        let segurancaExtraSslPinning = arguments["segurancaExtraSslPinning"] as? Bool ?? false
        let segurancaExtraEmulatorCheck = arguments["segurancaExtraEmulatorCheck"] as? Bool ?? false
        let timeoutCapturaManual = arguments["timeoutCapturaManual"] as? Double ?? 0.0
        let telaSelecaoDocumento = arguments["telaSelecaoDocumento"] as? Bool ?? false
        let resolucao = arguments["resolucao"] as? String ?? "low"
        let ladoDocumentoAceito = arguments["ladoDocumentoAceito"] as? String ?? ""
        let tipoRetorno = arguments["tipoRetorno"] as? String ?? "base64"
        let telaPreview = arguments["telaPreview"] as? Bool ?? true
        let scoreMinimo = arguments["scoreMinimo"] as? Int ?? 70
        let retornarErros = arguments["retornarErros"] as? Bool ?? false
        let verificarLuminosidade = arguments["verificarLuminosidade"] as? Bool ?? true
        let tokenTentativa = arguments["tokenTentativa"] as? Int ?? 0
        let orientacaoCaptura = arguments["orientacaoCaptura"] as? String ?? "portrait"
        let capturaManual = arguments["capturaManual"] as? Bool ?? false
        let tentativasDeCaptura = arguments["tentativasDeCaptura"] as? Int ?? 0
        let telaConfirmacaoDeSaida = arguments["telaConfirmacaoDeSaida"] as? Bool ?? true
        let spoof = arguments["spoof"] as? Bool ?? false
        let tentativasExibicaoBotao = arguments["tentativasExibicaoBotao"] as? Int ?? 3
        let playCaptureSound = arguments["playCaptureSound"] as? Bool ?? true
        let customizacaoTexto = arguments["configuracaoTexto"] as? [String: String] ?? [:]
        let customizacaoTextoDocumento = mapToTextConfiguration(custom: customizacaoTexto)
        let spoofValidationExceptions = arguments["spoofValidationExceptions"] as? [String] ?? [""]
        
        let captura = CapturarDocumentoViewController(
            chave: chave,
            cropDocumento: cropDocumento,
            validaDocumento: validaDocumento,
            wizard: wizard,
            aceitaAB: aceitaAB,
            tiposDocumentosAceitos: tiposDocumentosAceitos,
            segurancaExtraSslPinning: segurancaExtraSslPinning,
            timeoutCapturaManual: timeoutCapturaManual,
            telaSelecaoDocumento: telaSelecaoDocumento,
            resolucao: resolucao,
            ladoDocumentoAceito: ladoDocumentoAceito,
            tipoRetorno: tipoRetorno,
            telaPreview: telaPreview,
            scoreMinimo: scoreMinimo,
            customizacaoTexto: customizacaoTextoDocumento,
            retornarErros: retornarErros,
            verificarLuminosidade: verificarLuminosidade,
            segurancaExtraEmulatorCheck: segurancaExtraEmulatorCheck,
            tokenTentativa: tokenTentativa,
            orientacaoCaptura: orientacaoCaptura,
            capturaManual: capturaManual,
            tentativasDeCaptura: tentativasDeCaptura,
            telaConfirmacaoDeSaida: telaConfirmacaoDeSaida,
            spoof: spoof,
            tentativasExibicaoBotao: tentativasExibicaoBotao,
            playCaptureSound: playCaptureSound,
            spoofValidationExceptions: spoofValidationExceptions
        )
        view.backgroundColor = .white
        captura.delegate = self
        addChild(captura)
        view.addSubview(captura.view)
        captura.didMove(toParent: self)
        captura.view.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        captura.view.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        captura.view.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        captura.view.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        start()
    }
    
    func mapToTextConfiguration(custom: [String: String]?) -> ConfiguracaoTextoDocumento {
        let config = ConfiguracaoTextoDocumento()
        config.brscan_documento_error_upload_size_subtitle = custom?["brscan_documento_error_upload_size_subtitle"] ?? "" ;
        config.brscan_documento_uploading_digital_file_subtitle = custom?["brscan_documento_uploading_digital_file_subtitle"] ?? "" ;
        config.brscan_documento_uploading_digital_file_preparation_subtitle = custom?["brscan_documento_uploading_digital_file_preparation_subtitle"] ?? "" ;
        config.brscan_documento_loading_title = custom?["brscan_documento_loading_title"] ?? "" ;
        config.brscan_documento_capture_image_loading_subtitle = custom?["brscan_documento_capture_image_loading_subtitle"] ?? "" ;
        config.brscan_documento_capture_loading_upload_validation_image_subtitle = custom?["brscan_documento_capture_loading_upload_validation_image_subtitle"] ?? "" ;
        config.brscan_documento_captura_estado_aguardando_documento = custom?["brscan_documento_captura_estado_aguardando_documento"] ?? "" ;
        config.brscan_documento_captura_estado_aproxime_documento = custom?["brscan_documento_captura_estado_aproxime_documento"] ?? "" ;
        config.brscan_documento_captura_estado_afaste_documento = custom?["brscan_documento_captura_estado_afaste_documento"] ?? "" ;
        config.brscan_documento_captura_estado_aguarde = custom?["brscan_documento_captura_estado_aguarde"] ?? "" ;
        config.brscan_documento_captura_frente_rg = custom?["brscan_documento_captura_frente_rg"] ?? "" ;
        config.brscan_documento_captura_verso_rg = custom?["brscan_documento_captura_verso_rg"] ?? "" ;
        config.brscan_documento_captura_rg_aberto = custom?["brscan_documento_captura_rg_aberto"] ?? "" ;
        config.brscan_documento_captura_frente_cnh = custom?["brscan_documento_captura_frente_cnh"] ?? "" ;
        config.brscan_documento_captura_verso_cnh = custom?["brscan_documento_captura_verso_cnh"] ?? "" ;
        config.brscan_documento_captura_cnh_aberta = custom?["brscan_documento_captura_cnh_aberta"] ?? "" ;
        config.brscan_documento_captura_frente_documento = custom?["brscan_documento_captura_frente_documento"] ?? "" ;
        config.brscan_documento_captura_verso_documento = custom?["brscan_documento_captura_verso_documento"] ?? "" ;
        config.brscan_documento_captura_documento_aberto = custom?["brscan_documento_captura_documento_aberto"] ?? "" ;
        config.brscan_documento_error_connection_subtitle = custom?["brscan_documento_error_connection_subtitle"] ?? "" ;
        config.brscan_documento_erro_ao_validar_chave = custom?["brscan_documento_erro_ao_validar_chave"] ?? "" ;
        config.brscan_documento_error_low_light_subtitle = custom?["brscan_documento_error_low_light_subtitle"] ?? "" ;
        config.brscan_documento_erro_device_rooted = custom?["brscan_documento_erro_device_rooted"] ?? "" ;
        config.brscan_documento_erro_usuario_cancelou_acao = custom?["brscan_documento_erro_usuario_cancelou_acao"] ?? "" ;
        config.brscan_documento_error_proccess_not_completed_subtitle = custom?["brscan_documento_error_proccess_not_completed_subtitle"] ?? "" ;
        config.brscan_documento_error_connection_failed_subtitle = custom?["brscan_documento_error_connection_failed_subtitle"] ?? "" ;
        config.brscan_documento_error_image_validate_subtitle = custom?["brscan_documento_error_image_validate_subtitle"] ?? "" ;
        config.brscan_documento_error_invalid_document_subtitle = custom?["brscan_documento_error_invalid_document_subtitle"] ?? "" ;
        config.brscan_documento_error_different_document_subtitle = custom?["brscan_documento_error_different_document_subtitle"] ?? "" ;
        config.brscan_documento_error_token_expired_subtitle = custom?["brscan_documento_error_token_expired_subtitle"] ?? "" ;
        config.brscan_documento_erro_camera_indisponvel = custom?["brscan_documento_erro_camera_indisponvel"] ?? "" ;
        config.brscan_documento_error_different_side_A_subtitle = custom?["brscan_documento_error_different_side_A_subtitle"] ?? "" ;
        config.brscan_documento_error_different_side_B_subtitle = custom?["brscan_documento_error_different_side_B_subtitle"] ?? "" ;
        config.brscan_documento_erro_acesso_negado_title = custom?["brscan_documento_erro_acesso_negado_title"] ?? "" ;
        config.brscan_documento_error_enable_camera_subtitle = custom?["brscan_documento_error_enable_camera_subtitle"] ?? "" ;
        config.brscan_documento_captura_camera_botao_de_acao = custom?["brscan_documento_captura_camera_botao_de_acao"] ?? "" ;
        config.brscan_documento_erro_captura_title = custom?["brscan_documento_erro_captura_title"] ?? "" ;
        config.brscan_documento_erro_captura_subtitle = custom?["brscan_documento_erro_captura_subtitle"] ?? "" ;
        config.brscan_documento_error_button_try_again = custom?["brscan_documento_error_button_try_again"] ?? "" ;
        config.brscan_documento_erro_captura_botao_sair_do_processo = custom?["brscan_documento_erro_captura_botao_sair_do_processo"] ?? "" ;
        config.brscan_confirma_documento_frente_title = custom?["brscan_confirma_documento_frente_title"] ?? "" ;
        config.brscan_confirma_documento_frente_subtitle = custom?["brscan_confirma_documento_frente_subtitle"] ?? "" ;
        config.brscan_confirma_documento_verso_title = custom?["brscan_confirma_documento_verso_title"] ?? "" ;
        config.brscan_confirma_documento_verso_subtitle = custom?["brscan_confirma_documento_verso_subtitle"] ?? "" ;
        config.brscan_confirma_documento_ambos_title = custom?["brscan_confirma_documento_ambos_title"] ?? "" ;
        config.brscan_confirma_documento_ambos_subtitle = custom?["brscan_confirma_documento_ambos_subtitle"] ?? "" ;
        config.brscan_confirma_documento_continuar_botao_de_acao = custom?["brscan_confirma_documento_continuar_botao_de_acao"] ?? "" ;
        config.brscan_confirma_documento_finalizar_botao_de_acao = custom?["brscan_confirma_documento_finalizar_botao_de_acao"] ?? "" ;
        config.brscan_confirma_documento_repetir_botao_de_acao = custom?["brscan_confirma_documento_repetir_botao_de_acao"] ?? "" ;
        config.brscan_documento_proximo_processso_frente_title = custom?["brscan_documento_proximo_processso_frente_title"] ?? "" ;
        config.brscan_documento_proximo_processso_verso_title = custom?["brscan_documento_proximo_processso_verso_title"] ?? "" ;
        config.brscan_documento_proximo_processso_botao_de_acao = custom?["brscan_documento_proximo_processso_botao_de_acao"] ?? "" ;
        config.brscan_documento_sucesso_foto_valida = custom?["brscan_documento_sucesso_foto_valida"] ?? "" ;
        config.brscan_documento_erro_tentativas_permitidas = custom?["brscan_documento_erro_tentativas_permitidas"] ?? "" ;
        config.brscan_documento_choose_document_others_documents = custom?["brscan_documento_choose_document_others_documents"] ?? "";
        config.brscan_documento_choose_document_cdt_title = custom?["brscan_documento_choose_document_cdt_title"] ?? "";
        config.brscan_documento_choose_document_pre_approved_title = custom?["brscan_documento_choose_document_pre_approved_title"] ?? "";
        config.brscan_documento_choose_document_rne_rnm_title = custom?["brscan_documento_choose_document_rne_rnm_title"] ?? "";
        config.brscan_documento_choose_document_pre_approved_subtitle = custom?["brscan_documento_choose_document_pre_approved_subtitle"] ?? "";
        config.brscan_documento_choose_document_cnh_subtitle = custom?["brscan_documento_choose_document_cnh_subtitle"] ?? "";
        config.brscan_documento_choose_document_cdt_subtitle = custom?["brscan_documento_choose_document_cdt_subtitle"] ?? "";
        config.brscan_documento_choose_document_others_documents_subtitle = custom?["brscan_documento_choose_document_others_documents_subtitle"] ?? "";
        config.brscan_documento_choose_document_title = custom?["brscan_documento_choose_document_title"] ?? "";
        config.brscan_documento_choose_document_physical_radio_button_title = custom?["brscan_documento_choose_document_physical_radio_button_title"] ?? "";
        config.brscan_documento_choose_document_digital_radio_button_title = custom?["brscan_documento_choose_document_digital_radio_button_title"] ?? "";
        config.brscan_documento_choose_document_btn_positive = custom?["brscan_documento_choose_document_btn_positive"] ?? "";
        config.brscan_documento_error_invalid_file_subtitle = custom?["brscan_documento_error_invalid_file_subtitle"] ?? "";
        config.brscan_documento_erro_journey_empty_protocols = custom?["brscan_documento_erro_journey_empty_protocols"] ?? "";
        config.brscan_documento_captura_fotografe_documento = custom?["brscan_documento_captura_fotografe_documento"] ?? "";
        config.brscan_documento_captura_vire_documento = custom?["brscan_documento_captura_vire_documento"] ?? "";
        config.brscan_documento_sucesso_botao_finalizar = custom?["brscan_documento_sucesso_botao_finalizar"] ?? "";
        config.brscan_documento_instruction_digital_document_others_title = custom?["brscan_documento_instruction_digital_document_others_title"] ?? "";
        config.brscan_documento_instruction_digital_document_others_one = custom?["brscan_documento_instruction_digital_document_others_one"] ?? "";
        config.brscan_documento_instruction_digital_document_others_two = custom?["brscan_documento_instruction_digital_document_others_two"] ?? "";
        config.brscan_documento_instruction_digital_document_others_three = custom?["brscan_documento_instruction_digital_document_others_three"] ?? "";
        config.brscan_documento_instruction_digital_document_others_four = custom?["brscan_documento_instruction_digital_document_others_four"] ?? "";
        config.brscan_documento_instruction_digital_document_others_send_file = custom?["brscan_documento_instruction_digital_document_others_send_file"] ?? "";
        config.brscan_documento_instruction_digital_document_title = custom?["brscan_documento_instruction_digital_document_title"] ?? "";
        config.brscan_documento_instruction_digital_document_subtitle = custom?["brscan_documento_instruction_digital_document_subtitle"] ?? "";
        config.brscan_documento_instruction_digital_document_one = custom?["brscan_documento_instruction_digital_document_one"] ?? "";
        config.brscan_documento_instruction_digital_document_two = custom?["brscan_documento_instruction_digital_document_two"] ?? "";
        config.brscan_documento_instruction_digital_document_three = custom?["brscan_documento_instruction_digital_document_three"] ?? "";
        config.brscan_documento_instruction_digital_document_four = custom?["brscan_documento_instruction_digital_document_four"] ?? "";
        config.brscan_documento_instruction_digital_document_five = custom?["brscan_documento_instruction_digital_document_five"] ?? "";
        config.brscan_documento_instruction_digital_document_six = custom?["brscan_documento_instruction_digital_document_six"] ?? "";
        config.brscan_documento_instruction_digital_document_download_cdt = custom?["brscan_documento_instruction_digital_document_download_cdt"] ?? "";
        config.brscan_documento_instruction_digital_document_send_file = custom?["brscan_documento_instruction_digital_document_send_file"] ?? "";
        config.brscan_documento_select_digital_document_others_title = custom?["brscan_documento_select_digital_document_others_title"] ?? "";
        config.brscan_documento_select_digital_document_others_subtitle = custom?["brscan_documento_select_digital_document_others_subtitle"] ?? "";
        config.brscan_documento_select_digital_document_others_how_to_export = custom?["brscan_documento_select_digital_document_others_how_to_export"] ?? "";
        config.brscan_documento_select_digital_document_others_send_file = custom?["brscan_documento_select_digital_document_others_send_file"] ?? "";
        config.brscan_documento_select_digital_document_others_send_physical_doc = custom?["brscan_documento_select_digital_document_others_send_physical_doc"] ?? "";
        config.brscan_documento_select_digital_document_title = custom?["brscan_documento_select_digital_document_title"] ?? "";
        config.brscan_documento_select_digital_document_subtitle = custom?["brscan_documento_select_digital_document_subtitle"] ?? "";
        config.brscan_documento_select_digital_document_send_file = custom?["brscan_documento_select_digital_document_send_file"] ?? "";
        config.brscan_documento_select_digital_document_how_to_export = custom?["brscan_documento_select_digital_document_how_to_export"] ?? "";
        config.brscan_documento_select_digital_document_send_physical_doc = custom?["brscan_documento_select_digital_document_send_physical_doc"] ?? "";
        config.brscan_documento_digital_others_file_size_error = custom?["brscan_documento_digital_others_file_size_error"] ?? "";
        config.brscan_documento_digital_others_replace_file = custom?["brscan_documento_digital_others_replace_file"] ?? "";
        config.brscan_documento_digital_cnh_file_size_error = custom?["brscan_documento_digital_cnh_file_size_error"] ?? "";
        config.brscan_documento_digital_replace_file = custom?["brscan_documento_digital_replace_file"] ?? "";
        config.brscan_documento_continue_sending_document_title = custom?["brscan_documento_continue_sending_document_title"] ?? "" ;
        config.brscan_documento_continue_sending_document_subtitle = custom?["brscan_documento_continue_sending_document_subtitle"] ?? "" ;
        config.brscan_documento_continue_sending_document_btn_positive = custom?["brscan_documento_continue_sending_document_btn_positive"] ?? "" ;
        config.brscan_documento_continue_sending_document_btn_back_instructions = custom?["brscan_documento_continue_sending_document_btn_back_instructions"] ?? "" ;
        config.brscan_documento_success_screen_title = custom?["brscan_documento_success_screen_title"] ?? "" ;
        config.brscan_documento_error_spoof_subtitle = custom?["brscan_documento_error_spoof_subtitle"] ?? "" ;
        config.brscan_documento_error_opened_document_subtitle = custom?["brscan_documento_error_opened_document_subtitle"] ?? "" ;
        config.brscan_documento_error_closed_document_subtitle = custom?["brscan_documento_error_closed_document_subtitle"] ?? "" ;
        config.brscan_documento_captura_estado_mova_para_a_esquerda = custom?["brscan_documento_captura_estado_mova_para_a_esquerda"] ?? "" ;
        config.brscan_documento_captura_estado_mova_para_a_direita = custom?["brscan_documento_captura_estado_mova_para_a_direita"] ?? "" ;
        config.brscan_documento_captura_estado_mova_para_a_cima = custom?["brscan_documento_captura_estado_mova_para_a_cima"] ?? "" ;
        config.brscan_documento_captura_estado_mova_para_a_baixo = custom?["brscan_documento_captura_estado_mova_para_a_baixo"] ?? "" ;
        config.brscan_documento_captura_estado_documentos_na_horizontal = custom?["brscan_documento_captura_estado_documentos_na_horizontal"] ?? "" ;
        config.brscan_documento_preview_btn_positive = custom?["brscan_documento_preview_btn_positive"] ?? "" ;
        config.brscan_documento_preview_take_another_picture = custom?["brscan_documento_preview_take_another_picture"] ?? "" ;
        config.brscan_documento_capture_instruction_title = custom?["brscan_documento_capture_instruction_title"] ?? "" ;
        config.brscan_documento_capture_instruction_subtitle = custom?["brscan_documento_capture_instruction_subtitle"] ?? "" ;
        config.brscan_documento_capture_instruction_one = custom?["brscan_documento_capture_instruction_one"] ?? "" ;
        config.brscan_documento_capture_instruction_two = custom?["brscan_documento_capture_instruction_two"] ?? "" ;
        config.brscan_documento_capture_instruction_three = custom?["brscan_documento_capture_instruction_three"] ?? "" ;
        config.brscan_documento_capture_instruction_four = custom?["brscan_documento_capture_instruction_four"] ?? "" ;
        config.brscan_documento_capture_instruction_btn_positive = custom?["brscan_documento_capture_instruction_btn_positive"] ?? "" ;
        config.brscan_documento_error_connection_title = custom?["brscan_documento_error_connection_title"] ?? "" ;
        config.brscan_documento_error_low_light_title = custom?["brscan_documento_error_low_light_title"] ?? "" ;
        config.brscan_documento_error_enable_camera_title = custom?["brscan_documento_error_enable_camera_title"] ?? "" ;
        config.brscan_documento_error_connection_failed_title = custom?["brscan_documento_error_connection_failed_title"] ?? "" ;
        config.brscan_documento_error_proccess_not_completed_title = custom?["brscan_documento_error_proccess_not_completed_title"] ?? "" ;
        config.brscan_documento_error_image_validate_title = custom?["brscan_documento_error_image_validate_title"] ?? "" ;
        config.brscan_documento_error_invalid_document_title = custom?["brscan_documento_error_invalid_document_title"] ?? "" ;
        config.brscan_documento_error_different_document_title = custom?["brscan_documento_error_different_document_title"] ?? "" ;
        config.brscan_documento_error_no_document_title = custom?["brscan_documento_error_no_document_title"] ?? "" ;
        config.brscan_documento_error_different_side_A_title = custom?["brscan_documento_error_different_side_A_title"] ?? "" ;
        config.brscan_documento_error_different_side_B_title = custom?["brscan_documento_error_different_side_B_title"] ?? "" ;
        config.brscan_documento_error_token_expired_title = custom?["brscan_documento_error_token_expired_title"] ?? "" ;
        config.brscan_documento_error_opened_document_title = custom?["brscan_documento_error_opened_document_title"] ?? "" ;
        config.brscan_documento_error_closed_document_title = custom?["brscan_documento_error_closed_document_title"] ?? "" ;
        config.brscan_documento_error_spoof_title = custom?["brscan_documento_error_spoof_title"] ?? "" ;
        config.brscan_documento_error_upload_size_title = custom?["brscan_documento_error_upload_size_title"] ?? "" ;
        config.brscan_documento_error_invalid_file_title = custom?["brscan_documento_error_invalid_file_title"] ?? "" ;
        config.brscan_documento_invalid_document_instruction_one = custom?["brscan_documento_invalid_document_instruction_one"] ?? "" ;
        config.brscan_documento_invalid_document_instruction_two = custom?["brscan_documento_invalid_document_instruction_two"] ?? "" ;
        config.brscan_documento_invalid_document_instruction_three = custom?["brscan_documento_invalid_document_instruction_three"] ?? "" ;
        config.brscan_documento_no_document_instruction_one = custom?["brscan_documento_no_document_instruction_one"] ?? "" ;
        config.brscan_documento_no_document_instruction_two = custom?["brscan_documento_no_document_instruction_two"] ?? "" ;
        config.brscan_documento_no_document_instruction_three = custom?["brscan_documento_no_document_instruction_three"] ?? "" ;
        config.brscan_documento_image_validate_instruction_one = custom?["brscan_documento_image_validate_instruction_one"] ?? "" ;
        config.brscan_documento_image_validate_instruction_two = custom?["brscan_documento_image_validate_instruction_two"] ?? "" ;
        config.brscan_documento_image_validate_instruction_three = custom?["brscan_documento_image_validate_instruction_three"] ?? "" ;
        config.brscan_documento_image_validate_instruction_four = custom?["brscan_documento_image_validate_instruction_four"] ?? "" ;
        config.brscan_documento_error_low_light_instruction_one = custom?["brscan_documento_error_low_light_instruction_one"] ?? "" ;
        config.brscan_documento_error_low_light_instruction_two = custom?["brscan_documento_error_low_light_instruction_two"] ?? "" ;
        config.brscan_documento_error_low_light_instruction_three = custom?["brscan_documento_error_low_light_instruction_three"] ?? "" ;
        config.brscan_documento_error_low_light_instruction_four = custom?["brscan_documento_error_low_light_instruction_four"] ?? "" ;
        config.brscan_documento_exit_confirmation_title = custom?["brscan_documento_exit_confirmation_title"] ?? "" ;
        config.brscan_documento_exit_confirmation_subtitle = custom?["brscan_documento_exit_confirmation_subtitle"] ?? "" ;
        config.brscan_documento_exit_confirmation_button_positive = custom?["brscan_documento_exit_confirmation_button_positive"] ?? "" ;
        config.brscan_documento_exit_confirmation_button_negative = custom?["brscan_documento_exit_confirmation_button_negative"] ?? "" ;
        config.brscan_documento_captura_estado_inicial = custom?["brscan_documento_captura_estado_inicial"] ?? "" ;
        config.brscan_documento_captura_expect_side_b = custom?["brscan_documento_captura_expect_side_b"] ?? "" ;
        config.brscan_documento_captura_expect_side_a = custom?["brscan_documento_captura_expect_side_a"] ?? "" ;
        config.brscan_documento_captura_documento_lado_b = custom?["brscan_documento_captura_documento_lado_b"] ?? "" ;
        config.brscan_documento_captura_documento_lado_a = custom?["brscan_documento_captura_documento_lado_a"] ?? "" ;
        config.brscan_documento_captura_estado_documentos_aceitos = custom?["brscan_documento_captura_estado_documentos_aceitos"] ?? "" ;
        return config
    }
}

extension CapturaViewController: CapturarDocumentoViewControllerDelegate {
    public func sucesso(_ documento: [[String : Any]]) {
        let response: NSMutableDictionary = ["documentos" : documento]
        result.result!(response)
        navigationController?.popToRootViewController(animated: false)
    }
    
    public func erro(_ erro: [String : Any]) {
        let response : NSMutableDictionary! = [:]
        response["codigo"] = erro["codigo"]
        response["descricao"] = erro["descricao"]
        response["id"] = erro["id"]
        result.result!(response)
        navigationController?.popToRootViewController(animated: false)
    }
    
    public func documentCallbackListener(_ documentCallback: [String : Any]) {
        let response : NSMutableDictionary! = [:]
        response["code"] = documentCallback["code"]
        response["description"] = documentCallback["description"]
        response["id"] = documentCallback["id"]
        response["time"] = documentCallback["time"]
        response["type"] = documentCallback["type"]
        response["docType"] = documentCallback["docType"]
        response["image"] = documentCallback["image"]
        if let statusRequest = documentCallback["statusRequest"] as? Int {
            response["statusRequest"] = documentCallback["statusRequest"]
        }
        result.resultCallbackListener!(response)
    }
}

class DocumentResult {
    var result:  FlutterResult?
    var resultCallbackListener: FlutterResult?
}




