import 'package:flutter/services.dart';

const channelName = "serasa.idf/document";

const configuracaoTextoMap = {"brscan_documento_loading": "Aguarde overlay"};

const eventStartCapture = "startCapture";
const eventDocumentCallbackListener = "documentCallbackListener";
const eventFinishCapture = "finish";

const keyChave = "chave";
const keySegurancaExtraSslPinning = "segurancaExtraSslPinning";
const keyWizard = "wizard";
const keyAceitaAB = "aceitaAB";
const keyLadoDocumentoAceito = "ladoDocumentoAceito";
const keyTelaConfirmacaoSaida = "telaConfirmacaoDeSaida";
const keyTelaSelecaoDocumento = "telaSelecaoDocumento";
const keyCapturaManual = "capturaManual";
const keyOrientacaoCaptura = "orientacaoCaptura";
const keyScoreMinimo = "scoreMinimo";
const keyTelaPreview = "telaPreview";
const keyTentativasCaptura = "tentativasDeCaptura";
const keyTokenTentativa = "tokenTentativa";
const keyVerificarLuminosidade = "verificarLuminosidade";
const keyCropDocumento = "cropDocumento";
const keyValidaDocumento = "validaDocumento";
const keyTipoRetorno = "tipoRetorno";
const keyTimeoutCapturaManual = "timeoutCapturaManual";
const keyTiposDocumentosAceitos = "tiposDocumentosAceitos";
const keyResolucao = "resolucao";
const keyConfiguracaoTexto = "configuracaoTexto";
const keyRetornarErros = "retornarErros";
const keySegurancaExtraRootCheck = "segurancaExtraRootCheck";
const keySegurancaExtraEmulatorCheck = "segurancaExtraEmulatorCheck";
const keySpoof = "spoof";
const keyTentativasExibicaoBotao = "tentativasExibicaoBotao";
const keyPlayCaptureSound = "playCaptureSound";
const keySpoofValidationExceptions = "spoofValidationExceptions";
const keyBotaoCapturaVisivel = "botaoCapturaVisivel";

const keyResultIsOk = "isOk";
const keyResultId = "id";
const keyResultDocuments = "documentos";
const keyResultcallbackListener = "callbackListener";
const keyResultErrorCode = "codigo";
const keyResultErrorDescription = "descricao";
const keyResultCallbackCode = "code";
const keyResultCallbackDescription = "description";
const keyResultCallbackId = "id";
const keyResultCallbackTime = "time";
const keyResultCallbackType = "type";
const keyResultCallbackDocType = "docType";
const keyResultCallbackImage = "image";
const keyResultCallbackStatusRequest = "statusRequest";

const platform = MethodChannel(channelName);

void startCapture(
    {required Map params,
    required Function(Map document) onSuccess,
    required Function(Map error) onError,
    required Function(Map callbackListener) onCallbackListener}) async {
  try {
    startDocumentCallbackListener(onCallbackListener: onCallbackListener);
    Map result =
        await platform.invokeMethod<Map>(eventStartCapture, params) as Map;

    if (result.containsKey(keyResultDocuments)) {
      onSuccess(result);
    } else {
      onError(result);
    }
  } on PlatformException catch (e) {
    Map genericError = <String, Object>{};
    genericError[keyResultErrorCode] = -1;
    genericError[keyResultId] = "";
    genericError[keyResultErrorDescription] = e.message;
    onError(genericError);
  }
}

void startDocumentCallbackListener(
    {required Function(Map callbackListener) onCallbackListener}) async {
  try {
    Map result =
        await platform.invokeMethod<Map>(eventDocumentCallbackListener) as Map;
    onCallbackListener(result);
  } on PlatformException catch (_) {
  } finally {
    startDocumentCallbackListener(onCallbackListener: onCallbackListener);
  }
}

void finishProcess(
    {required Map params,
    required Function(Map document) onSuccess,
    required Function(Map error) onError}) async {
  try {
    Map result =
        await platform.invokeMethod<Map>(eventFinishCapture, params) as Map;

    if (result.containsKey(keyResultId)) {
      onSuccess(result);
    } else {
      onError(result);
    }
  } on PlatformException catch (e) {
    Map genericError = <String, Object>{};
    genericError[keyResultErrorCode] = -1;
    genericError[keyResultId] = "";
    genericError[keyResultErrorDescription] = e.message;
    onError(genericError);
  }
}
